import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Home, Grid, Tag, ShoppingBag, User, Headphones, ChevronUp } from 'lucide-react';

import Header from './components/Header';
import Footer from './components/Footer';
import HomeView from './components/HomeView';
import CategoriesView from './components/CategoriesView';
import OffersView from './components/OffersView';
import CartView from './components/CartView';
import AccountView from './components/AccountView';
import ProductDetailModal from './components/ProductDetailModal';
import SupportChat from './components/SupportChat';

import { PRODUCTS } from './data';
import { Product, CartItem, Coupon, Order } from './types';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('trang-chủ');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(null);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isChatOpen, setIsChatOpen] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Category and Manufacturer filter bridges
  const [catFilter, setCatFilter] = useState<string | undefined>(undefined);
  const [brandFilter, setBrandFilter] = useState<string | undefined>(undefined);

  // Initialize and load persistent elements
  useEffect(() => {
    try {
      const storedCart = localStorage.getItem('electro_pro_cart');
      if (storedCart) setCart(JSON.parse(storedCart));

      const storedOrders = localStorage.getItem('electro_pro_orders');
      if (storedOrders) setOrders(JSON.parse(storedOrders));
    } catch (e) {
      console.error("Local storage initializing failure:", e);
    }
  }, []);

  // Save cart modifications
  useEffect(() => {
    try {
      localStorage.setItem('electro_pro_cart', JSON.stringify(cart));
    } catch (e) {
      console.warn("Saving cart failure:", e);
    }
  }, [cart]);

  // Save order lists
  useEffect(() => {
    try {
      localStorage.setItem('electro_pro_orders', JSON.stringify(orders));
    } catch (e) {
      console.warn("Saving order database failure:", e);
    }
  }, [orders]);

  const handleNavigateToTab = (tab: string, filters?: { category?: string; manufacturer?: string }) => {
    setActiveTab(tab);
    setCatFilter(filters?.category);
    setBrandFilter(filters?.manufacturer);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleAddToCart = (product: Product, quantity: number) => {
    setCart(prev => {
      const existing = prev.find(item => item.product.id === product.id);
      if (existing) {
        return prev.map(item =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prev, { product, quantity }];
    });
  };

  const handleUpdateQuantity = (productId: string, delta: number) => {
    setCart(prev => {
      return prev.map(item => {
        if (item.product.id === productId) {
          const newQty = item.quantity + delta;
          return newQty > 0 ? { ...item, quantity: newQty } : item;
        }
        return item;
      }).filter(item => item.quantity > 0);
    });
  };

  const handleRemoveItem = (productId: string) => {
    setCart(prev => prev.filter(item => item.product.id !== productId));
  };

  const handlePlaceOrder = (newOrder: Order) => {
    setOrders(prev => [...prev, newOrder]);
    setCart([]); // Clean cart after order completion
    setAppliedCoupon(null); // Clean voucher
  };

  // Get related products for modal recommendations
  const getRelatedProducts = (prod: Product | null): Product[] => {
    if (!prod) return [];
    return PRODUCTS.filter(p => p.id !== prod.id && (p.category === prod.category || p.manufacturer === prod.manufacturer));
  };

  return (
    <div className="min-h-screen bg-[#f7f9fb] text-slate-900 flex flex-col font-sans selection:bg-primary/20">
      
      {/* Top Application Bar */}
      <Header 
        cartItems={cart}
        activeTab={activeTab}
        onNavigateToTab={handleNavigateToTab}
        onSearchChange={setSearchQuery}
        onToggleChat={() => setIsChatOpen(!isChatOpen)}
      />

      {/* Main Body area wrapped inside motion block transition */}
      <main className="flex-1 max-w-[1280px] mx-auto w-full px-4 md:px-8 py-6 mb-24 md:mb-6">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.25, ease: 'easeInOut' }}
          >
            {activeTab === 'trang-chủ' && (
              <HomeView 
                onNavigateToTab={handleNavigateToTab}
                onAddToCart={handleAddToCart}
                onViewDetails={setSelectedProduct}
              />
            )}

            {activeTab === 'danh-mục' && (
              <CategoriesView 
                initialCategory={catFilter}
                initialManufacturer={brandFilter}
                onAddToCart={handleAddToCart}
                onViewDetails={setSelectedProduct}
              />
            )}

            {activeTab === 'ưu-đãi' && (
              <OffersView 
                onNavigateToTab={handleNavigateToTab}
              />
            )}

            {activeTab === 'giỏ-hàng' && (
              <CartView 
                cartItems={cart}
                appliedCoupon={appliedCoupon}
                onUpdateQuantity={handleUpdateQuantity}
                onRemoveItem={handleRemoveItem}
                onApplyCoupon={setAppliedCoupon}
                onPlaceOrder={handlePlaceOrder}
                onNavigateToTab={handleNavigateToTab}
              />
            )}

            {activeTab === 'tài-khoản' && (
              <AccountView 
                orders={orders}
                onNavigateToTab={handleNavigateToTab}
              />
            )}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Bottom Navigation Grid (Mobile layout view matching exactly user prototype layout) */}
      <nav className="md:hidden fixed bottom-0 left-0 w-full z-50 flex justify-around items-center bg-white border-t border-slate-200 px-2 h-16 shadow-[0_-3px_12px_rgba(0,0,0,0.06)]">
        <button 
          onClick={() => handleNavigateToTab('trang-chủ')}
          className={`flex flex-col items-center justify-center pt-1.5 transition-all duration-250 ease-in-out ${
            activeTab === 'trang-chủ' ? 'text-primary border-t-2 border-primary' : 'text-slate-400 hover:text-slate-600'
          }`}
        >
          <Home className="w-5 h-5" />
          <span className="text-[9px] font-bold uppercase tracking-widest mt-1">Trang chủ</span>
        </button>

        <button 
          onClick={() => handleNavigateToTab('danh-mục')}
          className={`flex flex-col items-center justify-center pt-1.5 transition-all duration-250 ease-in-out ${
            activeTab === 'danh-mục' ? 'text-primary border-t-2 border-primary' : 'text-slate-400 hover:text-slate-600'
          }`}
        >
          <Grid className="w-5 h-5" />
          <span className="text-[9px] font-bold uppercase tracking-widest mt-1">Danh mục</span>
        </button>

        <button 
          onClick={() => handleNavigateToTab('ưu-đãi')}
          className={`flex flex-col items-center justify-center pt-1.5 transition-all duration-250 ease-in-out ${
            activeTab === 'ưu-đãi' ? 'text-primary border-t-2 border-primary' : 'text-slate-400 hover:text-slate-600'
          }`}
        >
          <Tag className="w-5 h-5" />
          <span className="text-[9px] font-bold uppercase tracking-widest mt-1">Ưu đãi</span>
        </button>

        <button 
          onClick={() => handleNavigateToTab('giỏ-hàng')}
          className={`flex flex-col items-center justify-center pt-1.5 transition-all duration-250 ease-in-out ${
            activeTab === 'giỏ-hàng' ? 'text-primary border-t-2 border-primary' : 'text-slate-400 hover:text-slate-600'
          }`}
        >
          <ShoppingBag className="w-5 h-5" />
          <span className="text-[9px] font-bold uppercase tracking-widest mt-1">Giỏ hàng</span>
        </button>

        <button 
          onClick={() => handleNavigateToTab('tài-khoản')}
          className={`flex flex-col items-center justify-center pt-1.5 transition-all duration-250 ease-in-out ${
            activeTab === 'tài-khoản' ? 'text-primary border-t-2 border-primary' : 'text-slate-400 hover:text-slate-600'
          }`}
        >
          <User className="w-5 h-5" />
          <span className="text-[9px] font-bold uppercase tracking-widest mt-1">Tài khoản</span>
        </button>
      </nav>

      {/* Floating Action Button (FAB) (Vietnam support line agent callout) */}
      <button 
        onClick={() => setIsChatOpen(!isChatOpen)}
        className="fixed bottom-20 md:bottom-8 right-6 bg-primary hover:bg-blue-800 text-white w-14 h-14 rounded-full shadow-lg flex items-center justify-center active:scale-90 transition-transform z-40 group"
        aria-label="Nhắn tin với kỹ sư"
      >
        <Headphones className="w-6 h-6 group-hover:rotate-12 transition-transform" />
      </button>

      {/* Dynamic Support Chat and Specs Modal overlays */}
      <SupportChat 
        isOpen={isChatOpen}
        onClose={() => setIsChatOpen(false)}
        onAddProductToCart={handleAddToCart}
        onNavigateToTab={handleNavigateToTab}
      />

      <ProductDetailModal 
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onAddToCart={handleAddToCart}
        relatedProducts={getRelatedProducts(selectedProduct)}
        onSelectProduct={setSelectedProduct}
      />

      {/* Corporate Desktop Footer */}
      <Footer onNavigateToTab={handleNavigateToTab} />
    </div>
  );
}
