import { Product, Coupon } from './types';

export const CATEGORIES = [
  { id: 'switch', label: 'Công tắc & Ổ cắm', icon: 'toggle_on' },
  { id: 'lighting', label: 'Đèn chiếu sáng', icon: 'lightbulb' },
  { id: 'breaker', label: 'Thiết bị đóng cắt', icon: 'settings_input_component' },
  { id: 'cable', label: 'Dây & Cáp điện', icon: 'cable' },
  { id: 'accessory', label: 'Phụ kiện', icon: 'rebase_edit' },
] as const;

export const PARTNERS = [
  { name: 'Panasonic', logoType: 'text' },
  { name: 'Schneider', logoType: 'text' },
  { name: 'PHILIPS', logoType: 'text' },
  { name: 'CADIVI', logoType: 'text' },
  { name: 'LS Electric', logoType: 'text' },
  { name: 'MITSUBISHI', logoType: 'text' },
];

export const PRODUCTS: Product[] = [
  {
    id: 'p1',
    name: 'CB Tép MCB Easy9 1P 16A 4.5kA 230V',
    manufacturer: 'Schneider Electric',
    category: 'breaker',
    categoryVietnamese: 'Thiết bị đóng cắt',
    price: 78000,
    originalPrice: 95000,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBwWN59Ehc3764rH5yO56wDgpEIXPqv1i6LtCtHJQ267haahZ6mZmGqTT5kiODV4iJGyc4XFRDcriT3STx2H0AnhhRLmz8EexFbjEFRiE7PWyxUtC6FveY0zsGMFfM3dA829hGa2a5MpfgXHcZD0LTez6wIHodyfbGT2lciBGONRSd4GNT0AFHWcCLiSWxZ5Atl5LWMPvRzuAu7AQP-Pm8zsq7GTJ4NXWBaB5cnftkv5lvOufMo9lTKdhHD-rCKBM6Jz4lyiDXvdh99',
    refCode: 'EZ9F34116',
    meta: 'REF: EZ9F34116',
    stock: 120,
    isNew: true,
    description: 'Aptomat tép MCB dòng Easy9 chất lượng cao của tập đoàn Schneider Electric, được thiết kế cho việc bảo vệ quá tải và ngắn mạch trong lưới điện dân dụng và công nghiệp nhẹ.',
    specs: {
      'Số cực': '1P (1 Cực)',
      'Dòng định mức (In)': '16A',
      'Khả năng cắt ngắn mạch': '4.5kA',
      'Điện áp định mức (Ue)': '230V AC',
      'Tiêu chuẩn': 'IEC 60898-1',
      'Độ bền cơ học': '10,000 lần đóng cắt'
    }
  },
  {
    id: 'p2',
    name: 'Đèn LED MyCare 12W E27 6500K 230V V V',
    manufacturer: 'Philips Lighting',
    category: 'lighting',
    categoryVietnamese: 'Đèn chiếu sáng',
    price: 115000,
    originalPrice: 140000,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCEVhJ95HTT5Yo94QLAQc2L6FY9XoFZYIiLaEmZsO6JyeM5dmT-ZIeY2frw-Fe5r2iIdZuCq0nsBn_PPrdvR6mAzYT1HvpA7GemJ-oyBCkyCOmK-ROQ3NuXW6_zFCYkyCyfXdXMrCuEElXBrCO1tKi8LzF11l_zzR1dEwKcF9WAnUKfg7_bwnzqeDgKhSqIth8sa47yzqMOEE9XvPvL-3B1DOt7pMTK05TJIdGxbaMHt2528Iy-4ywQ5FQzSxt1Pc7aiPGLZItQRhRk',
    refCode: 'PHILIPS-MC-12W',
    meta: 'IP20 | 1200lm',
    stock: 250,
    isNew: false,
    description: 'Đèn LED Philips MyCare tích hợp công nghệ tán quang hiện đại giúp dịu mắt EyeComfort, tiết kiệm tới 88% năng lượng so với bóng sợi đốt thông thường và có độ bền vượt trội.',
    specs: {
      'Công suất': '12W',
      'Đuôi đèn': 'E27',
      'Nhiệt độ màu': '6500K (Ánh sáng trắng)',
      'Quang thông': '1200 lm',
      'Điện áp': '220V - 240V',
      'Chỉ số hoàn màu (CRI)': '80 Ra',
      'Kích thước': '60 x 110 mm'
    }
  },
  {
    id: 'p3',
    name: 'Bộ công tắc đơn 1 chiều Wide Series',
    manufacturer: 'Panasonic',
    category: 'switch',
    categoryVietnamese: 'Công tắc & Ổ cắm',
    price: 42000,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAN0977NJZRSrP45vJ5F5Es9oqI7cf-n4jk4_SyIrXhH-DV91VSimn618qMadvZj5KPCcEHSLdXpA6rVymfdjBOGeW8MLC7fpxk_R_zdkQ76JI063xiJxx9G5pmugxWvJDOf71tqqdu3HVEG95KB027MirCjVfUWL6Q9A1cusbb7vrCk9Y6LZlQNqk3LwSUJOXfAGHOMVXGW2aSbW_iQN-tUi4um8PXgymNPATw_mucl5XCt4xA45lyCa5hpRSgZFA_yqUvRXlA-9Sz',
    refCode: 'WEV5001-7H',
    meta: 'MODERN WHITE',
    stock: 550,
    isNew: false,
    description: 'Bộ công tắc đơn 1 chiều dòng Wide Series của Panasonic, màu trắng hiện đại, thiết kế tinh tế vuông vức, phím bấm nhẹ êm tay, cấu tạo chống cháy an toàn tuyệt đối.',
    specs: {
      'Dòng sản phẩm': 'Wide Series',
      'Loại': 'Công tắc đơn 1 chiều',
      'Dòng định mức': '16A',
      'Điện áp': '250V AC',
      'Màu sắc': 'Trắng tuyết',
      'Chất liệu': 'Nhựa Urea Resin chống cháy'
    }
  },
  {
    id: 'p4',
    name: 'Dây điện đơn CV 2.5 mm2 - Cu/PVC 0.6/1kV',
    manufacturer: 'CADIVI',
    category: 'cable',
    categoryVietnamese: 'Dây & Cáp điện',
    price: 8450,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCC1N5b_UDNIK0_kmp_IaRgLRafu9RbNj7FZ6VXniat2mcA10qqkmSY8XKRemooOnKeA2Evh3AGaxKObOOp_1kaTNqb4o3rqXbhmV8NCm9OLpHAiGtpDv-Lj-fWmtZyQKismXs9-k4wRhdFg6TqT3sIRNDMwtUJG2ZHfh8xWlVPF183fyL802DtgcickPBu3e6mb76uiXYJmb3cIn4UiFnG711TOG9jUUaHRhaydYhbQxOlhZNixg1aGpo0aS41pjfQLCHLpZ-uI-YI',
    refCode: 'CADIVI-CV2.5',
    meta: 'JIS C 3307',
    stock: 1500,
    isNew: false,
    description: 'Dây cáp điện lực hạ thế một lõi đồng dẫn điện bọc cách điện bằng PVC chất lượng cao của CADIVI, độ ruột dẫn đồng tinh khiết 99.99%, cho khả năng truyền tải an toàn ổn định.',
    specs: {
      'Tiết diện ruột dẫn': '2.5 mm²',
      'Cấu tạo': 'Lõi đồng nhiều sợi xoắn (Class 2) / Cách điện PVC',
      'Nhiệt độ tối đa làm việc': '70°C',
      'Điện áp danh định': '0.6 / 1 kV',
      'Tiêu chuẩn': 'TCVN 6610-3 / JIS C 3307',
      'Độ dày cách điện': '0.8 mm'
    }
  },
  {
    id: 'p5',
    name: 'Ổ cắm đôi 3 chấu có màng che dòng Halumie',
    manufacturer: 'Panasonic',
    category: 'switch',
    categoryVietnamese: 'Công tắc & Ổ cắm',
    price: 110000,
    originalPrice: 125000,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAN0977NJZRSrP45vJ5F5Es9oqI7cf-n4jk4_SyIrXhH-DV91VSimn618qMadvZj5KPCcEHSLdXpA6rVymfdjBOGeW8MLC7fpxk_R_zdkQ76JI063xiJxx9G5pmugxWvJDOf71tqqdu3HVEG95KB027MirCjVfUWL6Q9A1cusbb7vrCk9Y6LZlQNqk3LwSUJOXfAGHOMVXGW2aSbW_iQN-tUi4um8PXgymNPATw_mucl5XCt4xA45lyCa5hpRSgZFA_yqUvRXlA-9Sz', // proxy
    refCode: 'WEV15037H',
    meta: 'HALUMIE MATT',
    stock: 350,
    isNew: true,
    description: 'Ổ cắm đôi có cực nối đất (3 chấu) dòng Halumie cao cấp của Panasonic. Có màn che chống giật bảo vệ trẻ em, màu xám ánh kim cực sang trọng phù hợp căn hộ hiện đại.',
    specs: {
      'Dòng sản phẩm': 'Halumie Series',
      'Loại': 'Ổ cắm đôi 3 chấu có màn che cực nối đất',
      'Dòng định mức': '16A',
      'Điện áp': '250V AC',
      'Tiêu chuẩn': 'IEC 60884-1'
    }
  },
  {
    id: 'p6',
    name: 'Aptomat chống giật RCBO Easy9 2P 32A 30mA',
    manufacturer: 'Schneider Electric',
    category: 'breaker',
    categoryVietnamese: 'Thiết bị đóng cắt',
    price: 385000,
    originalPrice: 420000,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBwWN59Ehc3764rH5yO56wDgpEIXPqv1i6LtCtHJQ267haahZ6mZmGqTT5kiODV4iJGyc4XFRDcriT3STx2H0AnhhRLmz8EexFbjEFRiE7PWyxUtC6FveY0zsGMFfM3dA829hGa2a5MpfgXHcZD0LTez6wIHodyfbGT2lciBGONRSd4GNT0AFHWcCLiSWxZ5Atl5LWMPvRzuAu7AQP-Pm8zsq7GTJ4NXWBaB5cnftkv5lvOufMo9lTKdhHD-rCKBM6Jz4lyiDXvdh99', // proxy
    refCode: 'EZ9D34632',
    meta: 'RCBO 30mA PROTECTION',
    stock: 95,
    isNew: true,
    description: 'Bộ ngắt tự động chống rò dòng và bảo vệ quá tải RCBO dòng Easy9 của Schneider. Đảm bảo an toàn tính mạng khi có sự cố rò điện xảy ra trong gia đình với ngưỡng nhảy cực nhạy 30mA.',
    specs: {
      'Số cực': '2P (1P + N)',
      'Dòng định mức': '32A',
      'Dòng rò định mức': '30mA (Threshold chống giật)',
      'Dòng cắt ngắn mạch': '4.5kA',
      'Tính năng': 'Bảo vệ quá tải, bảo vệ dòng rò, ngắn mạch'
    }
  },
  {
    id: 'p7',
    name: 'Dây cáp điện đôi mềm ovan dẹt VCmd 2x1.5',
    manufacturer: 'CADIVI',
    category: 'cable',
    categoryVietnamese: 'Dây & Cáp điện',
    price: 14500,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCC1N5b_UDNIK0_kmp_IaRgLRafu9RbNj7FZ6VXniat2mcA10qqkmSY8XKRemooOnKeA2Evh3AGaxKObOOp_1kaTNqb4o3rqXbhmV8NCm9OLpHAiGtpDv-Lj-fWmtZyQKismXs9-k4wRhdFg6TqT3sIRNDMwtUJG2ZHfh8xWlVPF183fyL802DtgcickPBu3e6mb76uiXYJmb3cIn4UiFnG711TOG9jUUaHRhaydYhbQxOlhZNixg1aGpo0aS41pjfQLCHLpZ-uI-YI', // proxy
    refCode: 'VCmd-2x1.5',
    meta: 'VCmd 300V LÕI ĐỒNG',
    stock: 1200,
    isNew: false,
    description: 'Cáp điện đôi mềm ruột đồng cách điện PVC dẹt (VCmd). Dùng cho các thiết bị điện di động dân dụng, ổ cắm kéo dài, quạt, đèn công nghệ nhẹ với độ bền lõi dây uốn nén tuyệt hảo.',
    specs: {
      'Số lõi': '2 lõi song song',
      'Tiết diện ruột dẫn': '2 x 1.5 mm²',
      'Ruột dẫn': 'Sợi đồng ủ mềm tinh khiết',
      'Điện áp định mức': '300V / 500V',
      'Quy cách bao gói': 'Cuộn 100 mét hoặc cắt lẻ'
    }
  },
  {
    id: 'p8',
    name: 'Bộ Đèn LED Tuýp 1.2m T8 18W Ecofit',
    manufacturer: 'Philips Lighting',
    category: 'lighting',
    categoryVietnamese: 'Đèn chiếu sáng',
    price: 95000,
    originalPrice: 110000,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCEVhJ95HTT5Yo94QLAQc2L6FY9XoFZYIiLaEmZsO6JyeM5dmT-ZIeY2frw-Fe5r2iIdZuCq0nsBn_PPrdvR6mAzYT1HvpA7GemJ-oyBCkyCOmK-ROQ3NuXW6_zFCYkyCyfXdXMrCuEElXBrCO1tKi8LzF11l_zzR1dEwKcF9WAnUKfg7_bwnzqeDgKhSqIth8sa47yzqMOEE9XvPvL-3B1DOt7pMTK05TJIdGxbaMHt2528Iy-4ywQ5FQzSxt1Pc7aiPGLZItQRhRk', // proxy
    refCode: 'PHILIPS-T8-1.2M',
    meta: '18W | 1800lm | SÁNG TRẮNG',
    stock: 180,
    description: 'Bộ đèn tuýp Led Ecofit 1.2m 18W của Philips bao gồm bóng và máng sắt tiện lợi. Thay thế hoàn hảo cho bóng huỳnh quang 36W truyền thống, tiết kiệm 50% điện năng tiêu thụ.',
    specs: {
      'Chiều dài': '1200 mm',
      'Kiểu bóng': 'T8 Tube',
      'Công suất': '18W',
      'Độ sáng': '1800 Lumen',
      'Góc chiếu': '160°'
    }
  },
  {
    id: 'p9',
    name: 'Mặt che mưa 3 cổng dòng Halumie IP43',
    manufacturer: 'Panasonic',
    category: 'accessory',
    categoryVietnamese: 'Phụ kiện',
    price: 49000,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAN0977NJZRSrP45vJ5F5Es9oqI7cf-n4jk4_SyIrXhH-DV91VSimn618qMadvZj5KPCcEHSLdXpA6rVymfdjBOGeW8MLC7fpxk_R_zdkQ76JI063xiJxx9G5pmugxWvJDOf71tqqdu3HVEG95KB027MirCjVfUWL6Q9A1cusbb7vrCk9Y6LZlQNqk3LwSUJOXfAGHOMVXGW2aSbW_iQN-tUi4um8PXgymNPATw_mucl5XCt4xA45lyCa5hpRSgZFA_yqUvRXlA-9Sz', // proxy
    refCode: 'WEV8901H',
    meta: 'WEATHERPROOF COVER',
    stock: 220,
    isNew: true,
    description: 'Mặt che mưa tự động đóng bằng nhựa dẻo chịu nhiệt ngoài trời của Panasonic. Bảo bối chống thấm nước tuyệt vời dành cho các ổ cắm sân vườn, ban công, nhà tắm ẩm ướt.',
    specs: {
      'Cấp bảo vệ': 'IP43 chịu mưa gió hắt nhẹ',
      'Chất liệu':'Nhựa Polycarbonate chống UV ăn mòn',
      'Lắp đặt': 'Lắp nổi / Lắp chìm',
      'Tương thích': 'Các mặt thiết bị dòng Wide và Halumie'
    }
  }
];

export const COUPONS: Coupon[] = [
  {
    code: 'THANG10',
    description: 'Giảm ngay 10% tổng giá trị đơn hàng',
    discountType: 'percent',
    discountValue: 10,
    minOrderValue: 200000
  },
  {
    code: 'CONGTRINH30',
    description: 'Giảm 30.000đ khi mua thiết bị đóng cắt áp dụng đơn từ 300.000đ',
    discountType: 'fixed',
    discountValue: 30000,
    minOrderValue: 300000,
    applicableCategory: 'breaker'
  },
  {
    code: 'FREESHIP',
    description: 'Miễn phí vận chuyển cho đơn hàng từ 500.000đ',
    discountType: 'percent',
    discountValue: 100, // Handle separately as raw shipping fee deduction
    minOrderValue: 500000
  }
];
