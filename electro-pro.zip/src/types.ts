export interface Product {
  id: string;
  name: string;
  manufacturer: string;
  category: 'switch' | 'lighting' | 'breaker' | 'cable' | 'accessory';
  categoryVietnamese: string;
  price: number;
  originalPrice?: number;
  image: string;
  refCode: string;
  meta: string; // "REF: EZ9F34116" or "IP20 | 1200lm" etc.
  stock: number;
  isNew?: boolean;
  description: string;
  specs: { [key: string]: string };
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface Coupon {
  code: string;
  description: string;
  discountType: 'percent' | 'fixed';
  discountValue: number;
  minOrderValue?: number;
  applicableCategory?: string;
}

export interface Order {
  id: string;
  date: string;
  customerName: string;
  phone: string;
  address: string;
  items: CartItem[];
  subtotal: number;
  discount: number;
  shippingFee: number;
  total: number;
  status: 'pending' | 'shipping' | 'completed' | 'cancelled';
  notes?: string;
  couponCode?: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  timestamp: Date;
}
