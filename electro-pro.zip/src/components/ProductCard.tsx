import React, { useState } from 'react';
import { ShoppingBag, Check, Eye } from 'lucide-react';
import { Product } from '../types';

interface ProductCardProps {
  key?: string | number;
  product: Product;
  onAddToCart: (product: Product, quantity: number) => void;
  onViewDetails: (product: Product) => void;
}

export default function ProductCard({ product, onAddToCart, onViewDetails }: ProductCardProps) {
  const [isAdded, setIsAdded] = useState(false);

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    onAddToCart(product, 1);
    setIsAdded(true);
    setTimeout(() => setIsAdded(false), 1500);
  };

  const formatVND = (num: number) => {
    return num.toLocaleString('vi-VN') + 'đ';
  };

  return (
    <div id={`product-card-${product.id}`} className="bg-white border border-slate-200 flex flex-col group relative hover:shadow-md transition-all duration-300">
      {/* Product Image Area */}
      <div className="relative h-64 overflow-hidden bg-slate-50 flex items-center justify-center p-8 select-none">
        <img 
          alt={product.name} 
          src={product.image} 
          referrerPolicy="no-referrer"
          className="max-h-full max-w-full object-contain group-hover:scale-105 transition-transform duration-300" 
        />
        
        {/* New Tag badge */}
        {product.isNew && (
          <div className="absolute top-2 right-2">
            <span className="border border-red-600 text-red-600 font-bold text-[10px] px-2 py-0.5 bg-white flex items-center gap-1 uppercase tracking-wider">
              <span className="w-1.5 h-1.5 rounded-full bg-red-600 inline-block animate-pulse"></span>
              Mới
            </span>
          </div>
        )}

        {/* View Details Hover Overlay Button */}
        <div className="absolute inset-0 bg-slate-950/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
          <button 
            type="button"
            onClick={() => onViewDetails(product)}
            className="bg-white/95 text-slate-800 font-bold text-xs px-3 py-2 rounded shadow flex items-center gap-1 hover:bg-white active:scale-95 transition-all"
          >
            <Eye className="w-3.5 h-3.5" />
            Xem kỹ thuật
          </button>
        </div>
      </div>

      {/* Main Stats Description */}
      <div className="p-4 flex-1 flex flex-col justify-between">
        <div>
          <p className="text-slate-500 text-[11px] font-bold uppercase mb-1 tracking-wider">
            {product.manufacturer}
          </p>
          <h3 
            onClick={() => onViewDetails(product)}
            className="font-semibold text-sm text-slate-800 mb-2 h-12 overflow-hidden hover:text-primary cursor-pointer line-clamp-2 transition-colors"
          >
            {product.name}
          </h3>
        </div>
        
        {/* Price representation */}
        <div className="flex justify-between items-end mt-2">
          <span className="text-primary font-bold text-lg">
            {formatVND(product.price)}
          </span>
          {product.originalPrice && (
            <span className="text-slate-400 line-through text-xs pb-0.5">
              {formatVND(product.originalPrice)}
            </span>
          )}
          {!product.originalPrice && (
            <span className="text-slate-400 text-xs pb-0.5 font-medium">
              Kho: {product.stock}+
            </span>
          )}
        </div>
      </div>

      {/* Embedded footer specification bar */}
      <div className="bg-slate-50 px-4 py-2 border-t border-slate-100 flex justify-between items-center h-12">
        <span className="font-mono text-xs text-slate-600 font-semibold truncate max-w-[130px]" title={product.meta}>
          {product.meta}
        </span>
        <button 
          onClick={handleAddToCart}
          className={`p-2 flex items-center justify-center transition-all duration-300 rounded ${
            isAdded 
              ? 'bg-emerald-600 text-white' 
              : 'bg-primary text-white hover:bg-blue-800 active:scale-95 shadow-sm'
          }`}
          aria-label={isAdded ? "Đã thêm vào giỏ hàng" : "Thêm vào giỏ hàng"}
        >
          {isAdded ? (
            <Check className="w-4 h-4 animate-bounce" />
          ) : (
            <ShoppingBag className="w-4 h-4" />
          )}
        </button>
      </div>
    </div>
  );
}
