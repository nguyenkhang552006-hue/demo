import React from 'react';
import { Bolt, ShoppingCart, Search, Menu, User, Sparkles, BookOpen } from 'lucide-react';
import { CartItem } from '../types';

interface HeaderProps {
  cartItems: CartItem[];
  activeTab: string;
  onNavigateToTab: (tab: string, filter?: { category?: string; manufacturer?: string }) => void;
  onSearchChange: (text: string) => void;
  onToggleChat: () => void;
}

export default function Header({
  cartItems,
  activeTab,
  onNavigateToTab,
  onSearchChange,
  onToggleChat,
}: HeaderProps) {
  const totalCartCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);

  const handleSearchSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const inputEl = e.currentTarget.querySelector('input') as HTMLInputElement;
    onSearchChange(inputEl?.value || '');
    onNavigateToTab('danh-mục');
  };

  return (
    <header className="bg-white border-b border-slate-200 flex justify-between items-center w-full px-6 py-4 sticky top-0 z-50 shadow-sm select-none">
      {/* Brand logo & tagline representation */}
      <div 
        onClick={() => onNavigateToTab('trang-chủ')}
        className="flex items-center gap-3 cursor-pointer group active:scale-[0.98] transition-transform"
      >
        <div className="bg-primary/15 text-primary p-2 rounded-lg group-hover:bg-primary group-hover:text-white transition-all duration-300">
          <Bolt className="w-6 h-6 animate-pulse" />
        </div>
        <div>
          <span className="text-lg md:text-xl font-black text-slate-900 uppercase tracking-tighter block leading-tight font-space-grotesk">
            ELECTRO PRO
          </span>
          <span className="text-[9px] text-slate-400 font-extrabold uppercase tracking-widest block leading-none">
            Tổng kho thiết bị điện
          </span>
        </div>
      </div>

      {/* Desktop Search bar proxy helper */}
      <form 
        onSubmit={handleSearchSubmit}
        className="hidden md:flex flex-1 max-w-xl mx-8 relative"
      >
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-4.5 h-4.5" />
        <input
          type="text"
          placeholder="Tìm hạt công tắc, aptomat bảo vệ, dây điện CADIVI..."
          className="w-full bg-slate-50 border border-slate-300 rounded-lg text-sm pl-10 pr-4 py-2.5 focus:border-primary focus:ring-1 focus:ring-primary focus:outline-none placeholder-slate-400 text-slate-800 transition-all font-medium"
          onChange={(e) => onSearchChange(e.target.value)}
        />
      </form>

      {/* Action controls shortcuts */}
      <div className="flex items-center gap-4">
        {/* Toggle support helper chat */}
        <button
          onClick={onToggleChat}
          className="hidden md:flex items-center gap-1.5 border border-slate-250 text-slate-600 hover:text-primary hover:border-primary font-bold text-xs px-3.5 py-2 rounded-lg transition-colors bg-white shadow-sm"
        >
          <BookOpen className="w-4 h-4 text-primary" />
          Kỹ sư tư vấn
        </button>

        {/* Shopping Cart button with numeric badge overlay */}
        <button
          onClick={() => onNavigateToTab('giỏ-hàng')}
          className={`relative p-2.5 rounded-full transition-colors ${
            activeTab === 'giỏ-hàng' 
              ? 'bg-primary text-white' 
              : 'bg-slate-50 text-slate-600 hover:bg-slate-100 hover:text-slate-900'
          }`}
          aria-label="Xem giỏ hàng"
        >
          <ShoppingCart className="w-5 h-5" />
          {totalCartCount > 0 && (
            <span className="absolute -top-1.5 -right-1.5 bg-red-600 text-white text-[10px] font-black w-5 h-5 rounded-full flex items-center justify-center border-2 border-white animate-bounce-short">
              {totalCartCount}
            </span>
          )}
        </button>

        {/* Account Shortcut */}
        <button
          onClick={() => onNavigateToTab('tài-khoản')}
          className={`p-2.5 rounded-full transition-colors hidden sm:block ${
            activeTab === 'tài-khoản' 
              ? 'bg-primary text-white' 
              : 'bg-slate-50 text-slate-600 hover:bg-slate-100'
          }`}
          aria-label="Tài khoản nhà thầu"
        >
          <User className="w-5 h-5" />
        </button>
      </div>
    </header>
  );
}
