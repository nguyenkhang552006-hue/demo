import React, { useState } from 'react';
import { ShoppingCart, Plus, Minus, Trash2, Tag, Truck, CheckCircle2, Ticket, Sparkles, Building, CreditCard, ChevronRight } from 'lucide-react';
import { CartItem, Coupon, Order } from '../types';
import { COUPONS } from '../data';

interface CartViewProps {
  cartItems: CartItem[];
  appliedCoupon: Coupon | null;
  onUpdateQuantity: (id: string, delta: number) => void;
  onRemoveItem: (id: string) => void;
  onApplyCoupon: (coupon: Coupon | null) => void;
  onPlaceOrder: (order: Order) => void;
  onNavigateToTab: (tab: string) => void;
}

export default function CartView({
  cartItems,
  appliedCoupon,
  onUpdateQuantity,
  onRemoveItem,
  onApplyCoupon,
  onPlaceOrder,
  onNavigateToTab,
}: React.PropsWithChildren<CartViewProps>) {
  const [couponInput, setCouponInput] = useState('');
  const [couponError, setCouponError] = useState<string | null>(null);
  
  // Recipient Shipping state handles
  const [fullname, setFullname] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [notes, setNotes] = useState('');
  const [shippingMethod, setShippingMethod] = useState<'standard' | 'express'>('standard');
  const [checkoutStep, setCheckoutStep] = useState<'cart' | 'checkout' | 'success'>('cart');
  const [placedOrderDetails, setPlacedOrderDetails] = useState<Order | null>(null);
  const [inputErrors, setInputErrors] = useState<{ [key: string]: string }>({});

  const standardShippingFee = 30000;
  const expressShippingFee = 55000;
  
  // Calculate pricing numbers
  const subtotal = cartItems.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  
  // Determine shipping cost
  let shippingFee = shippingMethod === 'standard' ? standardShippingFee : expressShippingFee;
  if (appliedCoupon?.code === 'FREESHIP' && subtotal >= 500000) {
    shippingFee = 0;
  }

  // Calculate discount values based on promo code rules
  let discount = 0;
  if (appliedCoupon) {
    if (appliedCoupon.code === 'THANG10' && subtotal >= (appliedCoupon.minOrderValue || 0)) {
      discount = Math.round(subtotal * 0.1);
    } else if (appliedCoupon.code === 'CONGTRINH30' && subtotal >= (appliedCoupon.minOrderValue || 0)) {
      // Check if breaker products exist inside cart
      const hasBreaker = cartItems.some(item => item.product.category === 'breaker');
      if (hasBreaker) {
        discount = 30000;
      }
    }
  }

  const grandTotal = subtotal - discount + shippingFee;

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    setCouponError(null);
    const codeSearched = couponInput.trim().toUpperCase();

    if (!codeSearched) {
      onApplyCoupon(null);
      return;
    }

    const foundCoupon = COUPONS.find(c => c.code === codeSearched);

    if (!foundCoupon) {
      setCouponError('Mã khuyến mãi không tồn tại trong hệ thống!');
      return;
    }

    // Validate minimal order requirements
    if (foundCoupon.minOrderValue && subtotal < foundCoupon.minOrderValue) {
      setCouponError(`Giá trị đơn hàng tối thiểu chưa đạt. Cần thêm ${(foundCoupon.minOrderValue - subtotal).toLocaleString('vi-VN')}đ nữa.`);
      return;
    }

    // Specific category validation
    if (foundCoupon.applicableCategory) {
      const isApplicable = cartItems.some(item => item.product.category === foundCoupon.applicableCategory);
      if (!isApplicable) {
        setCouponError('Mã ưu đãi này chỉ áp dụng cho nhóm Thiết bị đóng cắt (Breaker).');
        return;
      }
    }

    onApplyCoupon(foundCoupon);
    setCouponError(null);
  };

  const validateForm = () => {
    const errs: { [key: string]: string } = {};
    if (!fullname.trim()) errs.fullname = 'Vui lòng cung cấp họ và tên người nhận!';
    if (!phone.trim()) {
      errs.phone = 'Vui lòng điền số điện thoại liên hệ!';
    } else if (!/^[0-9]{10,11}$/.test(phone.trim())) {
      errs.phone = 'Số điện thoại không đúng định dạng (phải từ 10-11 chữ số)!';
    }
    if (!address.trim()) errs.address = 'Vui lòng cung cấp địa chỉ nhận hàng chi tiết!';
    
    setInputErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleOrderSubmit = () => {
    if (!validateForm()) return;

    const newOrder: Order = {
      id: `EL-${Math.floor(100000 + Math.random() * 900000)}`,
      date: new Date().toLocaleDateString('vi-VN', { year: 'numeric', month: '2-digit', day: '2-digit' }),
      customerName: fullname,
      phone: phone,
      address: address,
      items: [...cartItems],
      subtotal: subtotal,
      discount: discount,
      shippingFee: shippingFee,
      total: grandTotal,
      status: 'pending',
      notes: notes,
      couponCode: appliedCoupon?.code
    };

    onPlaceOrder(newOrder);
    setPlacedOrderDetails(newOrder);
    setCheckoutStep('success');
  };

  const handleResetCheckout = () => {
    setFullname('');
    setPhone('');
    setAddress('');
    setNotes('');
    setCheckoutStep('cart');
    setPlacedOrderDetails(null);
  };

  const formatVND = (num: number) => {
    return num.toLocaleString('vi-VN') + 'đ';
  };

  if (checkoutStep === 'success' && placedOrderDetails) {
    return (
      <div className="max-w-2xl mx-auto py-8 text-center space-y-6 select-text">
        <div className="bg-white border border-slate-200 p-8 rounded-lg shadow-sm space-y-6">
          <div className="inline-flex items-center justify-center bg-emerald-100 p-4 rounded-full text-emerald-600">
            <CheckCircle2 className="w-16 h-16" />
          </div>
          <div className="space-y-2">
            <h2 className="text-2xl font-bold text-slate-800">Đặt hàng thành công!</h2>
            <p className="text-sm text-slate-500">
              Mã số hóa đơn: <strong className="text-primary text-base font-mono">{placedOrderDetails.id}</strong>
            </p>
            <p className="text-xs text-slate-400">
              Đơn hàng của bạn đã được chuyển tới phòng kho bãi và vận hành kỹ sư để bọc gói.
            </p>
          </div>

          <div className="border-t border-b border-slate-100 py-4 text-left space-y-3 text-sm">
            <div className="flex justify-between">
              <span className="text-slate-400">Khách hàng nhận:</span>
              <span className="font-bold text-slate-850">{placedOrderDetails.customerName}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Số điện thoại:</span>
              <span className="font-bold text-slate-850">{placedOrderDetails.phone}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Địa chỉ giao hàng:</span>
              <span className="font-bold text-slate-850 max-w-[280px] text-right truncate" title={placedOrderDetails.address}>
                {placedOrderDetails.address}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Phương thức:</span>
              <span className="font-bold text-slate-850 capitalize">
                {placedOrderDetails.shippingFee === 0 ? 'Miễn phí vận chuyển' : 'Vận chuyển tiêu chuẩn'}
              </span>
            </div>
            <div className="flex justify-between pt-2 border-t border-dashed border-slate-100">
              <span className="text-slate-800 font-bold">Tổng thanh toán:</span>
              <span className="font-bold text-primary text-lg">{formatVND(placedOrderDetails.total)}</span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 pt-2">
            <button
              onClick={() => onNavigateToTab('tài-khoản')}
              className="flex-1 bg-slate-900 hover:bg-slate-800 text-white font-bold py-3 text-xs uppercase tracking-wider rounded transition-colors"
            >
              Xem trạng thái giao hàng
            </button>
            <button
              onClick={() => {
                handleResetCheckout();
                onNavigateToTab('trang-chủ');
              }}
              className="flex-1 border border-slate-300 hover:bg-slate-50 text-slate-700 font-bold py-3 text-xs uppercase tracking-wider rounded transition-colors"
            >
              Tiếp tục mua sắm
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div id="cart-view" className="space-y-6 py-2 select-text">
      {/* Tab switch header state */}
      <div className="border-b border-slate-200 pb-3 flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-slate-900 uppercase">Giỏ hàng của bạn</h2>
          <p className="text-xs text-slate-500 mt-1">Kênh đặt hàng chiết khấu, lấy hóa đơn nhanh công trình</p>
        </div>
        <div className="flex items-center gap-2 text-xs font-bold text-slate-400 uppercase">
          <span className={`${checkoutStep === 'cart' ? 'text-primary' : 'text-slate-400'}`}>1. Giỏ hàng</span>
          <ChevronRight className="w-3 h-3" />
          <span className={`${checkoutStep === 'checkout' ? 'text-primary' : 'text-slate-400'}`}>2. Giao hàng</span>
        </div>
      </div>

      {cartItems.length === 0 ? (
        <div className="text-center py-16 border rounded bg-slate-50 border-dashed border-slate-200">
          <ShoppingCart className="w-12 h-12 text-slate-300 mx-auto mb-4" />
          <h3 className="text-lg font-bold text-slate-700">Giỏ hàng của bạn đang trống!</h3>
          <p className="text-sm text-slate-400 mt-1">Chưa chọn sản phẩm thiết bị hạ thế nào cho dự án.</p>
          <button
            onClick={() => onNavigateToTab('danh-mục')}
            className="mt-6 bg-primary text-white font-bold text-xs uppercase px-6 py-3 rounded hover:bg-md-blue active:scale-95 transition-transform shadow-sm"
          >
            Tìm mua linh kiện ngay
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main items panel */}
          {checkoutStep === 'cart' ? (
            <div className="lg:col-span-2 space-y-4">
              <div className="bg-white border border-slate-200 rounded divide-y divide-slate-100">
                {cartItems.map((item) => (
                  <div key={item.product.id} className="p-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                    <div className="flex items-center gap-4 flex-1">
                      <div className="w-16 h-16 bg-slate-50 border p-2 flex items-center justify-center rounded flex-shrink-0">
                        <img 
                          alt={item.product.name} 
                          src={item.product.image} 
                          referrerPolicy="no-referrer"
                          className="max-h-full max-w-full object-contain" 
                        />
                      </div>
                      <div className="space-y-1">
                        <span className="text-[10px] bg-slate-100 px-2 py-0.5 rounded text-slate-500 font-bold uppercase block tracking-wider w-fit">
                          {item.product.manufacturer}
                        </span>
                        <h4 className="font-semibold text-slate-800 text-sm">{item.product.name}</h4>
                        <div className="flex items-center gap-3 text-xs text-slate-400">
                          <span>Mã: <code className="text-slate-600 font-bold">{item.product.refCode}</code></span>
                          <span>|</span>
                          <span>Đơn giá: <strong className="text-slate-700">{formatVND(item.product.price)}</strong></span>
                        </div>
                      </div>
                    </div>

                    {/* Quantity Adjustment Controls */}
                    <div className="flex items-center gap-6 w-full sm:w-auto justify-between sm:justify-end">
                      <div className="flex items-center border border-slate-200 rounded overflow-hidden select-none">
                        <button
                          type="button"
                          onClick={() => onUpdateQuantity(item.product.id, -1)}
                          className="px-2.5 py-1.5 hover:bg-slate-100 text-slate-500 hover:text-slate-800"
                        >
                          <Minus className="w-3.5 h-3.5" />
                        </button>
                        <span className="px-3 py-1 font-mono text-sm text-slate-800 font-bold bg-slate-50 border-l border-r border-slate-100">
                          {item.quantity}
                        </span>
                        <button
                          type="button"
                          onClick={() => onUpdateQuantity(item.product.id, 1)}
                          className="px-2.5 py-1.5 hover:bg-slate-100 text-slate-500 hover:text-slate-800"
                        >
                          <Plus className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="flex items-center gap-4">
                        <span className="font-bold text-slate-850 font-mono text-sm">
                          {formatVND(item.product.price * item.quantity)}
                        </span>
                        <button
                          type="button"
                          onClick={() => onRemoveItem(item.product.id)}
                          className="text-slate-400 hover:text-red-650 p-1 hover:bg-slate-50 rounded transition-colors"
                          aria-label="Xóa sản phẩm"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            // Delivery detail checkouts
            <div className="lg:col-span-2 bg-white border border-slate-200 rounded p-6 space-y-4">
              <h3 className="font-bold text-slate-800 text-sm uppercase border-b border-slate-100 pb-2">Hồ sơ giao hàng & nhận tiền (COD):</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label htmlFor="recipient-name" className="text-xs font-bold text-slate-600 uppercase tracking-wider block">Họ tên người nhận <span className="text-red-500">*</span></label>
                  <input
                    id="recipient-name"
                    type="text"
                    value={fullname}
                    onChange={(e) => setFullname(e.target.value)}
                    placeholder="Nguyen Van A..."
                    className="w-full bg-slate-50 border border-slate-300 rounded px-3 py-2 text-sm text-slate-800 focus:outline-none focus:ring-1 focus:ring-primary"
                  />
                  {inputErrors.fullname && <p className="text-red-600 text-xs font-semibold">{inputErrors.fullname}</p>}
                </div>
                
                <div className="space-y-1">
                  <label htmlFor="recipient-phone" className="text-xs font-bold text-slate-600 uppercase tracking-wider block">Số điện thoại <span className="text-red-500">*</span></label>
                  <input
                    id="recipient-phone"
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="0912xxxxxx"
                    className="w-full bg-slate-50 border border-slate-300 rounded px-3 py-2 text-sm text-slate-800 focus:outline-none focus:ring-1 focus:ring-primary"
                  />
                  {inputErrors.phone && <p className="text-red-600 text-xs font-semibold">{inputErrors.phone}</p>}
                </div>
              </div>

              <div className="space-y-1">
                <label htmlFor="delivery-address" className="text-xs font-bold text-slate-600 uppercase tracking-wider block">Địa chỉ nhận hàng <span className="text-red-500">*</span></label>
                <input
                  id="delivery-address"
                  type="text"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="Số nhà, Tên đường, Quận/Huyện, Tỉnh thành..."
                  className="w-full bg-slate-50 border border-slate-300 rounded px-3 py-2 text-sm text-slate-800 focus:outline-none focus:ring-1 focus:ring-primary"
                />
                {inputErrors.address && <p className="text-red-600 text-xs font-semibold">{inputErrors.address}</p>}
              </div>

              {/* Delivery Speed Selector Option */}
              <div className="space-y-2">
                <span className="text-xs font-bold text-slate-600 uppercase tracking-wider block">Vận chuyển:</span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div 
                    onClick={() => setShippingMethod('standard')}
                    className={`p-3 border rounded cursor-pointer transition-colors ${
                      shippingMethod === 'standard' ? 'border-primary bg-blue-50/50' : 'border-slate-200 hover:border-slate-350 bg-slate-50'
                    }`}
                  >
                    <div className="flex justify-between items-center">
                      <span className="text-xs font-bold text-slate-800 uppercase flex items-center gap-1">
                        <Truck className="w-4 h-4 text-primary" /> Tiết Kiệm (Có COD)
                      </span>
                      <span className="font-mono text-xs font-bold text-slate-600">30.000đ</span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1 leading-normal">
                      Nhận hàng trong 2-3 ngày làm việc. Áp dụng miễn phí toàn quốc cho đơn từ 500k.
                    </p>
                  </div>

                  <div 
                    onClick={() => setShippingMethod('express')}
                    className={`p-3 border rounded cursor-pointer transition-colors ${
                      shippingMethod === 'express' ? 'border-primary bg-blue-50/50' : 'border-slate-200 hover:border-slate-350 bg-slate-50'
                    }`}
                  >
                    <div className="flex justify-between items-center">
                      <span className="text-xs font-bold text-slate-800 uppercase flex items-center gap-1">
                        <Sparkles className="w-4 h-4 text-primary" /> Hỏa tốc 24H (Nội thành)
                      </span>
                      <span className="font-mono text-xs font-bold text-slate-600">55.000đ</span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1 leading-normal">
                      Bàn giao tận tay tại chân công trình sau 2-4 tiếng trong ngày kể từ khi duyệt.
                    </p>
                  </div>
                </div>
              </div>

              <div className="space-y-1">
                <label htmlFor="delivery-notes" className="text-xs font-bold text-slate-600 uppercase tracking-wider block">Ghi chú giao nhận / Xuất hóa đơn VAT</label>
                <textarea
                  id="delivery-notes"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Ghi rõ thông tin Công ty xuất hóa đơn (nếu cần), hoặc lời dặn anh giao hàng..."
                  rows={2}
                  className="w-full bg-slate-50 border border-slate-300 rounded px-3 py-2 text-sm text-slate-800 focus:outline-none focus:ring-1 focus:ring-primary"
                />
              </div>
            </div>
          )}

          {/* Right Summary Panel */}
          <aside className="space-y-6">
            <div className="bg-slate-50 border border-slate-200 rounded p-6 space-y-4">
              <h3 className="font-bold text-slate-800 text-sm uppercase border-b border-slate-250 pb-2">Tóm tắt đơn hàng</h3>
              
              <div className="space-y-3 text-xs leading-normal font-medium">
                <div className="flex justify-between text-slate-500">
                  <span>Trọng số thiết bị ({cartItems.reduce((acc, i) => acc + i.quantity, 0)} hạt):</span>
                  <span className="font-mono">{formatVND(subtotal)}</span>
                </div>
                {appliedCoupon && (
                  <div className="flex justify-between text-emerald-600">
                    <span className="flex items-center gap-1">
                      <Ticket className="w-3.5 h-3.5" /> Chiết khấu:
                    </span>
                    <span className="font-mono">-{formatVND(discount)}</span>
                  </div>
                )}
                <div className="flex justify-between text-slate-500">
                  <span>Phí bọc hàng & vận chuyển:</span>
                  <span className="font-mono">{shippingFee === 0 ? 'Thỏa thuận miễn phí' : formatVND(shippingFee)}</span>
                </div>
                
                <div className="border-t border-dashed border-slate-200 pt-3 flex justify-between font-bold text-sm text-slate-800">
                  <span>Tổng cộng thanh toán:</span>
                  <span className="text-primary font-mono text-base">{formatVND(grandTotal)}</span>
                </div>
              </div>

              {/* Promo input action (only during cart review stage) */}
              {checkoutStep === 'cart' && (
                <form onSubmit={handleApplyCoupon} className="space-y-2 pt-2 border-t border-slate-200">
                  <label htmlFor="coupon-input" className="text-xs font-bold text-slate-600 uppercase tracking-widest block">Mã giảm giá</label>
                  <div className="flex gap-2">
                    <div className="relative flex-1">
                      <Tag className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400 w-3.5 h-3.5" />
                      <input
                        id="coupon-input"
                        type="text"
                        value={couponInput}
                        onChange={(e) => setCouponInput(e.target.value)}
                        placeholder="THANG10, FREESHIP..."
                        className="w-full bg-white border border-slate-300 rounded pl-8 pr-2 py-1.5 text-xs text-slate-800 focus:outline-none"
                      />
                    </div>
                    <button
                      type="submit"
                      className="bg-primary text-white font-bold text-xs uppercase px-3 py-1.5 rounded hover:bg-blue-800 ml-1.5"
                    >
                      Áp dụng
                    </button>
                  </div>
                  {couponError && <p className="text-red-600 text-[10px] font-semibold">{couponError}</p>}
                  {appliedCoupon && (
                    <div className="bg-emerald-50 border border-emerald-200 p-2 rounded flex items-center justify-between text-[11px] text-emerald-850">
                      <span className="font-bold flex items-center gap-1">
                        ✓ Mã {appliedCoupon.code} được duyệt!
                      </span>
                      <button 
                        type="button"
                        onClick={() => {
                          onApplyCoupon(null);
                          setCouponInput('');
                        }} 
                        className="text-slate-400 hover:text-red-700 underline font-bold"
                      >
                        Gỡ bỏ
                      </button>
                    </div>
                  )}
                </form>
              )}

              {/* Steps control actions */}
              {checkoutStep === 'cart' ? (
                <button
                  type="button"
                  onClick={() => setCheckoutStep('checkout')}
                  className="w-full bg-primary hover:bg-blue-850 text-white font-bold py-3 text-xs uppercase tracking-wider rounded transition-colors flex items-center justify-center gap-1"
                >
                  Tiến hành giao hàng <ChevronRight className="w-4 h-4" />
                </button>
              ) : (
                <div className="space-y-2 pt-2">
                  <button
                    type="button"
                    onClick={handleOrderSubmit}
                    className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3 text-xs uppercase tracking-wider rounded transition-colors flex items-center justify-center gap-1.5"
                  >
                    Xác nhận đặt hàng (COD)
                  </button>
                  <button
                    type="button"
                    onClick={() => setCheckoutStep('cart')}
                    className="w-full border border-slate-300 text-slate-600 hover:bg-slate-50 font-bold py-2 text-xs uppercase tracking-wider rounded transition-colors"
                  >
                    Quay lại kiểm tra giỏ
                  </button>
                </div>
              )}
            </div>

            {/* Quick trust metrics panel */}
            <div className="bg-slate-50 border border-slate-200 rounded p-4 text-xs text-slate-500 space-y-2 font-medium">
              <span className="font-bold text-slate-700 uppercase block tracking-wider">Đảm bảo giao dịch:</span>
              <p className="flex items-center gap-1.5">
                <Building className="w-3.5 h-3.5 text-primary" /> Bảo mật thông tin nhà thầu 100%.
              </p>
              <p className="flex items-center gap-1.5">
                <CreditCard className="w-3.5 h-3.5 text-primary" /> Thanh toán COD: Kiểm tra kỹ, test thông mạch ok mới chuyển tiền.
              </p>
            </div>
          </aside>
        </div>
      )}
    </div>
  );
}
