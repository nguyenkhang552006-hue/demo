import React from 'react';
import { ArrowRight, ToggleLeft, Lightbulb, ShieldAlert, Cable, Wrench, ArrowUpRight, Award, Zap, ShieldCheck, Truck } from 'lucide-react';
import { Product } from '../types';
import { CATEGORIES, PRODUCTS, PARTNERS } from '../data';
import ProductCard from './ProductCard';

interface HomeViewProps {
  onNavigateToTab: (tab: string, filter?: { category?: string; manufacturer?: string }) => void;
  onAddToCart: (product: Product, quantity: number) => void;
  onViewDetails: (product: Product) => void;
}

export default function HomeView({ onNavigateToTab, onAddToCart, onViewDetails }: HomeViewProps) {
  // Get leading 4 products for showcasing on the home grid (Easy9, MyCare, Wide Switch, CADIVI cable)
  const homeProducts = PRODUCTS.slice(0, 4);

  const getCategoryIconComp = (iconName: string) => {
    switch (iconName) {
      case 'toggle_on':
        return <ToggleLeft className="w-8 h-8 text-primary" />;
      case 'lightbulb':
        return <Lightbulb className="w-8 h-8 text-primary" />;
      case 'settings_input_component':
        return <ShieldAlert className="w-8 h-8 text-primary" />;
      case 'cable':
        return <Cable className="w-8 h-8 text-primary" />;
      case 'rebase_edit':
      default:
        return <Wrench className="w-8 h-8 text-primary" />;
    }
  };

  return (
    <div id="home-view" className="space-y-12 py-4">
      {/* Hero Banner Section */}
      <section className="relative w-full h-[400px] overflow-hidden bg-slate-950 flex items-center rounded-lg shadow-sm">
        <div className="absolute inset-0 z-0 select-none">
          <img 
            alt="Smart Home Tech" 
            src="https://lh3.googleusercontent.com/aida-public/AB6AXuCizjgmn5z26M25dm-V7u_LO5eb6grZ5Uih583fpJ0r-wxm0MJJzqPq8S76ynWlQbU7ksXrVDSl0HYylnIJ9by2t9kV7DXaJTs3e7Z5xLeWRDlDe2zgyi97Tw8W2XSBXxDj_sE0yW5eOfATg4lmLtJkQbLUewjcurXDrOy0VoJlMOIth2FCJy8IbbcmdNlWpFP7wUgAARpfPYcQGkjn6ATY_WSN2EkqQS-3fs9NqxQPBm2nr4zk0D-ehvSHjVc7eL-xDe_DCKwk9MX4"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover opacity-50 hover:scale-[1.02] transition-transform duration-1000" 
          />
        </div>
        <div className="relative z-10 px-8 max-w-2xl text-left select-text">
          <span className="bg-primary hover:bg-blue-800 text-white font-bold text-xs tracking-wider uppercase px-3 py-1.5 mb-4 inline-block transition-colors rounded">
            KHUYẾN MÃI THÁNG 10
          </span>
          <h1 className="text-3xl md:text-5xl font-extrabold text-white mb-4 tracking-tight leading-tight">
            GIẢI PHÁP ĐIỆN THÔNG MINH CHO CÔNG TRÌNH
          </h1>
          <p className="text-slate-200 text-sm md:text-base mb-8 leading-relaxed font-medium">
            Giảm tới 30% cho các thiết bị đóng cắt và hệ thống chiếu sáng công nghiệp. Cam kết hàng chính hãng 100%, đầy đủ giấy tờ CO/CQ chứng thực.
          </p>
          <div className="flex flex-wrap gap-4">
            <button 
              type="button"
              onClick={() => onNavigateToTab('ưu-đãi')}
              className="bg-primary text-white px-8 py-3.5 font-bold uppercase hover:bg-blue-850 active:scale-95 transition-all text-xs tracking-wider rounded"
            >
              Xem ưu đãi
            </button>
            <button 
              type="button"
              onClick={() => onNavigateToTab('danh-mục')}
              className="border border-white text-white px-8 py-3.5 font-bold uppercase hover:bg-white hover:text-slate-900 active:scale-95 transition-all text-xs tracking-wider rounded"
            >
              Catalog 2024
            </button>
          </div>
        </div>
      </section>

      {/* Feature Badges Section (Added technical credibility) */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-6 bg-slate-50 p-6 border border-slate-200 rounded-lg">
        <div className="flex items-start gap-4">
          <div className="bg-primary/10 p-3 rounded-lg text-primary flex-shrink-0">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h4 className="font-bold text-slate-800 text-sm uppercase">100% Chính Hãng</h4>
            <p className="text-xs text-slate-500 mt-1">Sản phẩm đầy đủ CO/CQ từ Panasonic, Schneider, Philips, Cadivi.</p>
          </div>
        </div>
        <div className="flex items-start gap-4">
          <div className="bg-primary/10 p-3 rounded-lg text-primary flex-shrink-0">
            <Zap className="w-6 h-6" />
          </div>
          <div>
            <h4 className="font-bold text-slate-800 text-sm uppercase">Tư Vấn Kỹ Thuật Chuyên Sâu</h4>
            <p className="text-xs text-slate-500 mt-1">Đội ngũ kỹ sư hỗ trợ tính toán tải tiêu thụ, chọn tiết diện cáp tối ưu.</p>
          </div>
        </div>
        <div className="flex items-start gap-4">
          <div className="bg-primary/10 p-3 rounded-lg text-primary flex-shrink-0">
            <Truck className="w-6 h-6" />
          </div>
          <div>
            <h4 className="font-bold text-slate-800 text-sm uppercase">Giao Hàng Công Trình Siêu Tốc</h4>
            <p className="text-xs text-slate-500 mt-1">Miễn phí ship khu vực nội thành cho đơn hàng từ 500.000đ.</p>
          </div>
        </div>
      </section>

      {/* Product Categories Section */}
      <section className="space-y-6">
        <div className="flex justify-between items-end border-b border-slate-200 pb-3">
          <div>
            <h2 className="text-2xl font-bold tracking-tight text-slate-900 uppercase">Danh mục hàng</h2>
            <div className="h-1 w-20 bg-primary mt-1.5 rounded-full"></div>
          </div>
          <span className="text-xs text-slate-500 font-mono hidden md:inline">5 PHÂN KHÚC ĐIỆN VẬT TƯ CHÍNH</span>
        </div>
        
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
          {CATEGORIES.map((cat) => (
            <div 
              key={cat.id}
              onClick={() => onNavigateToTab('danh-mục', { category: cat.id })}
              className="group bg-white border border-slate-200 p-6 flex flex-col items-center justify-center text-center cursor-pointer hover:border-primary hover:shadow-sm transition-all duration-200 rounded"
            >
              <div className="w-14 h-14 rounded-full bg-slate-50 flex items-center justify-center mb-4 group-hover:bg-blue-50 transition-colors">
                {getCategoryIconComp(cat.icon)}
              </div>
              <span className="font-bold text-slate-800 text-xs md:text-sm group-hover:text-primary transition-colors">
                {cat.label}
              </span>
            </div>
          ))}
        </div>
      </section>

      {/* New Arrivals Section */}
      <section className="space-y-6">
        <div className="flex justify-between items-center border-l-4 border-primary pl-4">
          <h2 className="text-2xl font-bold text-slate-900 uppercase tracking-wide">Sản phẩm mới về</h2>
          <button 
            type="button"
            onClick={() => onNavigateToTab('danh-mục')}
            className="text-primary font-bold text-xs flex items-center gap-1 hover:underline tracking-wider uppercase"
          >
            Tất cả <ArrowRight className="w-4 h-4 ml-0.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {homeProducts.map((product) => (
            <ProductCard 
              key={product.id}
              product={product}
              onAddToCart={onAddToCart}
              onViewDetails={onViewDetails}
            />
          ))}
        </div>
      </section>

      {/* Partner Brands (Trust Grid) */}
      <section className="space-y-6 pb-6">
        <div className="text-center">
          <h2 className="text-xl font-bold text-slate-800 uppercase tracking-widest">Thương hiệu đối tác</h2>
          <p className="text-xs text-slate-500 mt-1 uppercase font-semibold">Nhà sản xuất thiết bị hàng đầu thế giới & việt nam</p>
        </div>
        
        <div className="bg-white border border-slate-200 overflow-hidden rounded shadow-sm">
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 divide-x divide-y divide-slate-100 border-collapse">
            {PARTNERS.map((partner, i) => (
              <div 
                key={i}
                onClick={() => onNavigateToTab('danh-mục', { manufacturer: partner.name })}
                className="p-8 flex items-center justify-center opacity-60 hover:opacity-100 hover:bg-slate-50 transition-all cursor-pointer select-none"
              >
                <div className="text-center">
                  <span className="text-slate-400 font-extrabold text-base md:text-lg tracking-wider block group-hover:text-primary">
                    {partner.name.toUpperCase()}
                  </span>
                  <span className="text-[9px] text-primary/70 font-bold uppercase block tracking-widest mt-1">Official</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
