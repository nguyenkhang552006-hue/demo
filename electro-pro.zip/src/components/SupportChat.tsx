import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User as UserIcon, X, Headphones, Sparkles, MessageSquare, Lightbulb, ShieldAlert, Cpu } from 'lucide-react';
import { ChatMessage, Product } from '../types';
import { PRODUCTS } from '../data';

interface SupportChatProps {
  isOpen: boolean;
  onClose: () => void;
  onAddProductToCart: (product: Product, quantity: number) => void;
  onNavigateToTab: (tab: string) => void;
}

const PRESET_TOPICS = [
  { text: 'Chọn dây CADIVI theo dải công suất?', icon: Sparkles },
  { text: 'Tư vấn Aptomat chống giật Schneider', icon: ShieldAlert },
  { text: 'Đèn LED Philips MyCare có ưu điểm gì?', icon: Lightbulb },
  { text: 'Xem các mã khuyến mãi hiện có', icon: Cpu }
];

export default function SupportChat({ isOpen, onClose, onAddProductToCart, onNavigateToTab }: SupportChatProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      sender: 'bot',
      text: 'Xin chào! Tôi là Trợ Lý Kỹ Thuật Electro Pro. Tôi có hại thế kiến thức về thiết bị điện Panasonic, Schneider, Philips, CADIVI. Bạn muốn tư vấn sản phẩm hay tính toán tải công trình?',
      timestamp: new Date()
    }
  ]);
  const [input, setInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isOpen]);

  const handleSend = (textToSend: string) => {
    if (!textToSend.trim()) return;

    const userMsg: ChatMessage = {
      id: `u-${Date.now()}`,
      sender: 'user',
      text: textToSend,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');

    // Generate responsive response in 800ms
    setTimeout(() => {
      let replyText = '';
      const query = textToSend.toLowerCase();

      if (query.includes('cadivi') || query.includes('dây') || query.includes('cáp')) {
        replyText = `📌 **Tư vấn chọn dây điện CADIVI:**\n- Cho thiết bị công suất nhỏ (Quạt, đèn gia đình <1000W): Dùng **VCmd 2x0.75** hoặc **VCmd 2x1.5** (Giá chỉ 14.500đ/mét).\n- Cho phụ tải ổ cắm thông thường (<3000W): Dùng cáp **CV 2.5 mm²** (mã CADIVI-CV2.5 đang giảm còn 8.450đ/mét - cực kỳ an toàn cho mạng điện trong tường).\n- Cho bếp từ, điều hòa lớn (<5000W): Khuyến cáo chọn dây **CV 4.0 mm²** hoặc **CV 6.0 mm²**.\n\n👉 *Tôi đã liệt kê dây CV 2.5 mm2 trong danh mục của hệ thống, bạn có thể nhấn xem chi tiết hoặc thêm vào giỏ hàng ngay!*`;
      } else if (query.includes('schneider') || query.includes('aptomat') || query.includes('mcb') || query.includes('chống giật') || query.includes('cb')) {
        replyText = `⚡ **Giải pháp Aptomat bảo vệ an toàn Schneider:**\nChúng tôi phân phối dòng **Schneider Easy9** nguyên chiếc chính hãng:\n1. CB Tép MCB Easy9 16A (Mã EZ9F34116): Dùng cho tải nhánh, điều hòa phòng khách nhỏ. Giá khuyến mãi **78.000đ** (gốc 95.000đ).\n2. RCBO Chống rò dòng chống giật 32A 30mA (Mã EZ9D34632): Bảo vệ tính mạng khi rò rỉ. Giá: **385.000đ**.\n\n*Mẹo an toàn:* Nên lắp RCBO chống giật ở các khu bếp hoặc bình nóng lạnh nhà tắm! Bạn có muốn mua sản phẩm này?";`;
      } else if (query.includes('philips') || query.includes('đèn') || query.includes('led') || query.includes('chiếu sáng')) {
        replyText = `💡 **Công nghệ Đèn LED Philips MyCare:**\n- Công suất **12W** (Đuôi E27 tiêu chuẩn, ánh sáng 6500K) đang có giá cực hời **115.000đ**.\n- Giúp bảo vệ mắt nhờ công nghệ thấu kính tán quang mịn (EyeComfort).\n- Tuổi thọ lên đến 15.000 giờ, tiết kiệm 88% điện năng.\n\nBạn có muốn trang bị cho hệ thống chiếu sáng không?`;
      } else if (query.includes('panasonic') || query.includes('công tắc') || query.includes('ổ cắm') || query.includes('mặt che')) {
        replyText = `🔌 **Thiết bị Panasonic cao cấp:**\n- Dòng **Wide Series** đại diện cho sự bền bỉ, hạt công tắc đơn 1 chiều có giá chỉ **42.000đ**.\n- Dòng **Halumie** sang trọng với ổ cắm 3 chấu có màn che an toàn giá **110.000đ**.\n- Có phụ kiện **mặt che mưa chống thấm IP43** giá **49.000đ** lắp ở ban công hoặc nhà tắm.\n\nCác sản phẩm này đều làm từ vật liệu nhựa cao cấp Urea Resin chống cháy nổ tuyệt hảo.`;
      } else if (query.includes('khuyến mãi') || query.includes('giảm giá') || query.includes('coupon') || query.includes('ưu đãi') || query.includes('mã')) {
        replyText = `🎁 **Danh sách khuyến mãi ELECTRO PRO đang áp dụng:**\n1. \`THANG10\`: Giảm **10%** tổng đơn hàng từ 200.000đ.\n2. \`CONGTRINH30\`: Giảm ngay **30.000đ** cho đơn Breaker (thiết bị đóng cắt) từ 300.000đ.\n3. \`FREESHIP\`: Miễn phí giao hàng toàn quốc từ 500.000đ.\n\nBạn hãy lưu các mã này để áp dụng tại trang thanh toán giỏ hàng nhé!`;
      } else {
        replyText = `Cảm ơn bạn đã hỏi về: "${textToSend}". \n\nTại **Electro Pro**, chúng tôi cam kết phân phối 100% vật tư chính hãng của Panasonic, Schneider, Philips, CADIVI với đầy đủ chứng nhận CO/CQ. \n\nBạn có thể duyệt nhanh danh mục sản phẩm, thêm vào giỏ hàng và nhập ưu đãi \`THANG10\` để nhận giá chiết khấu đặc biệt nhất! Bạn cần hỏi về thông số kỹ thuật nào khác không?`;
      }

      const botMsg: ChatMessage = {
        id: `b-${Date.now()}`,
        sender: 'bot',
        text: replyText,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, botMsg]);
    }, 850);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed bottom-24 right-4 md:right-12 w-full max-w-[420px] h-[550px] bg-white border border-slate-200 shadow-xl flex flex-col z-50 rounded-xl overflow-hidden animate-in fade-in slide-in-from-bottom-6">
      {/* Target ID attribute added according to HTML ID Attribute Guidelines */}
      <div id="chat-header" className="bg-primary text-white p-4 flex items-center justify-between border-b border-primary/20">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center">
            <Headphones className="w-5 h-5 text-on-primary" />
          </div>
          <div>
            <h3 className="font-bold text-sm leading-tight">Hỗ Trợ Kỹ Thuật 24/7</h3>
            <span className="text-xs text-white/70 flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block animate-pulse"></span>
              Đội kỹ sư đang online
            </span>
          </div>
        </div>
        <button 
          onClick={onClose} 
          className="text-white/80 hover:text-white p-1 hover:bg-white/10 rounded-full transition-colors"
          aria-label="Đóng Chat"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-4 bg-slate-50 space-y-4">
        {messages.map(msg => (
          <div 
            key={msg.id} 
            className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'} items-start gap-2.5`}
          >
            {msg.sender === 'bot' && (
              <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center mt-1 flex-shrink-0">
                <Bot className="w-4 h-4 text-primary" />
              </div>
            )}
            <div className={`max-w-[80%] rounded-lg p-3 text-sm leading-normal shadow-[0_1px_2px_rgba(0,0,0,0.05)] ${
              msg.sender === 'user' 
                ? 'bg-primary text-white font-medium rounded-tr-none' 
                : 'bg-white text-slate-800 border border-slate-200 rounded-tl-none whitespace-pre-wrap'
            }`}>
              {msg.text}
              <div className={`text-[10px] mt-1 text-right block ${msg.sender === 'user' ? 'text-white/60' : 'text-slate-400'}`}>
                {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </div>
            </div>
            {msg.sender === 'user' && (
              <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center mt-1 flex-shrink-0">
                <UserIcon className="w-4 h-4 text-slate-600" />
              </div>
            )}
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      {/* Suggestion tags */}
      <div className="px-3 py-2 bg-slate-100 border-t border-slate-200/60 overflow-x-auto whitespace-nowrap flex gap-2">
        {PRESET_TOPICS.map((topic, i) => {
          const IconComp = topic.icon;
          return (
            <button
              key={i}
              onClick={() => handleSend(topic.text)}
              className="inline-flex items-center gap-1.5 bg-white border border-slate-300 hover:border-primary text-xs font-medium px-2.5 py-1.5 rounded-full text-slate-700 transition-colors"
            >
              <IconComp className="w-3.5 h-3.5 text-primary" />
              {topic.text}
            </button>
          );
        })}
      </div>

      {/* Input controls */}
      <form 
        onSubmit={(e) => {
          e.preventDefault();
          handleSend(input);
        }}
        className="p-3 bg-white border-t border-slate-200 flex gap-2 items-center"
      >
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Hỏi tải định mức, báo giá chiết khấu tại đây..."
          className="flex-1 bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary placeholder-slate-400 text-slate-800"
        />
        <button
          type="submit"
          className="bg-primary text-white p-2 rounded-lg hover:bg-primary/95 active:scale-95 transition-transform flex items-center justify-center"
          aria-label="Gửi tin nhắn"
        >
          <Send className="w-4 h-4" />
        </button>
      </form>
    </div>
  );
}
