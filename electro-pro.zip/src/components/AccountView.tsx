import React, { useState } from 'react';
import { User, ClipboardList, MapPin, Sparkles, Building, Briefcase, TrendingUp, History, CheckCircle2, AlertTriangle, ShieldCheck } from 'lucide-react';
import { Order } from '../types';

interface AccountViewProps {
  orders: Order[];
  onNavigateToTab: (tab: string) => void;
}

export default function AccountView({ orders, onNavigateToTab }: AccountViewProps) {
  const [fullname, setFullname] = useState('Nguyễn Khánh Tân');
  const [email] = useState('nguyenkhantan@gmail.com');
  const [role, setRole] = useState('Nhà thầu Cơ điện - Công trình');
  const [company, setCompany] = useState('Tan Nguyen M&E Consulting');
  const [isSaved, setIsSaved] = useState(false);

  const formatVND = (num: number) => {
    return num.toLocaleString('vi-VN') + 'đ';
  };

  const handleUpdateProfile = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2000);
  };

  const getOrderStatusLabel = (status: Order['status']) => {
    switch (status) {
      case 'pending':
        return (
          <span className="bg-amber-50 text-amber-700 border border-amber-200 px-2.5 py-1 rounded text-xs font-bold uppercase flex items-center gap-1 w-fit">
            <AlertTriangle className="w-3.5 h-3.5" /> Chờ xác nhận
          </span>
        );
      case 'shipping':
        return (
          <span className="bg-blue-50 text-blue-700 border border-blue-250 px-2.5 py-1 rounded text-xs font-bold uppercase flex items-center gap-1 w-fit animate-pulse">
            <History className="w-3.5 h-3.5" /> Đang vận chuyển
          </span>
        );
      case 'completed':
        return (
          <span className="bg-emerald-50 text-emerald-800 border border-emerald-200 px-2.5 py-1 rounded text-xs font-bold uppercase flex items-center gap-1 w-fit">
            <CheckCircle2 className="w-3.5 h-3.5" /> Hoàn tất thành công
          </span>
        );
      default:
        return (
          <span className="bg-slate-100 text-slate-500 border border-slate-250 px-2.5 py-1 rounded text-xs font-bold uppercase block w-fit">
            Đã hủy
          </span>
        );
    }
  };

  return (
    <div id="account-view" className="space-y-8 py-2 select-text">
      {/* Title */}
      <div className="border-b border-slate-200 pb-3">
        <h2 className="text-2xl font-bold tracking-tight text-slate-900 uppercase">Bảng điều khiển Nhà thầu</h2>
        <p className="text-xs text-slate-500 mt-1">
          Quản lý tài khoản đấu thầu, theo dõi hóa đơn và báo giá vật tư điện hạ thế
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Side: Profile Form representation */}
        <div className="bg-white border border-slate-200 rounded p-6 space-y-6">
          <div className="flex items-center gap-3">
            <div className="bg-primary text-white p-3 rounded-full">
              <User className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-slate-800 text-sm uppercase">Cá nhân hóa tài khoản</h3>
              <span className="text-xs text-slate-400 font-medium">Lưu cài đặt cho hóa đơn kế toán</span>
            </div>
          </div>

          <form onSubmit={handleUpdateProfile} className="space-y-4">
            <div className="space-y-1">
              <label htmlFor="user-fullname" className="text-xs font-bold text-slate-600 uppercase tracking-wider block">Họ và tên</label>
              <input
                id="user-fullname"
                type="text"
                value={fullname}
                onChange={(e) => setFullname(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded px-3 py-2 text-sm text-slate-800 focus:outline-none"
              />
            </div>

            <div className="space-y-1">
              <label htmlFor="user-email" className="text-xs font-bold text-slate-600 uppercase tracking-wider block">Email đại lý</label>
              <input
                id="user-email"
                type="email"
                value={email}
                disabled
                className="w-full bg-slate-100 border border-slate-200 text-slate-400 rounded px-3 py-2 text-sm cursor-not-allowed"
              />
            </div>

            <div className="space-y-1">
              <label htmlFor="user-role" className="text-xs font-bold text-slate-600 uppercase tracking-wider block">Vai trò kĩ thuật</label>
              <input
                id="user-role"
                type="text"
                value={role}
                onChange={(e) => setRole(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded px-3 py-2 text-sm text-slate-800 focus:outline-none"
              />
            </div>

            <div className="space-y-1">
              <label htmlFor="user-company" className="text-xs font-bold text-slate-600 uppercase tracking-wider block">Công ty liên kết</label>
              <input
                id="user-company"
                type="text"
                value={company}
                onChange={(e) => setCompany(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded px-3 py-2 text-sm text-slate-800 focus:outline-none"
              />
            </div>

            <button
              type="submit"
              className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold py-2.5 text-xs uppercase tracking-wider rounded transition-colors"
            >
              Cập nhật thông tin nhận báo giá
            </button>

            {isSaved && (
              <p className="text-emerald-700 text-xs font-bold text-center bg-emerald-50 border border-emerald-200 p-2 rounded">
                ✓ Đã lưu thành công cấu hình hồ sơ thi công!
              </p>
            )}
          </form>
        </div>

        {/* Right Side: Active orders list tracking */}
        <div className="lg:col-span-2 space-y-6">
          {/* Numeric quick facts widgets */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="bg-slate-50 border border-slate-200 p-5 rounded flex items-center justify-between">
              <div>
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Hóa đơn công trình</span>
                <span className="block text-xl font-bold font-mono text-slate-800 mt-0.5">{orders.length} đơn</span>
              </div>
              <ClipboardList className="w-8 h-8 text-primary" />
            </div>

            <div className="bg-slate-50 border border-slate-200 p-5 rounded flex items-center justify-between">
              <div>
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Tổng mức chi tiêu</span>
                <span className="block text-xl font-bold font-mono text-primary mt-0.5">
                  {formatVND(orders.reduce((acc, current) => acc + current.total, 0))}
                </span>
              </div>
              <TrendingUp className="w-8 h-8 text-emerald-650" />
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="font-bold text-slate-800 text-sm uppercase flex items-center gap-1.5 border-b border-slate-100 pb-2">
              <ClipboardList className="w-4.5 h-4.5 text-slate-600" /> Bản kê khai đơn mua hiện hành:
            </h3>

            {orders.length === 0 ? (
              <div className="text-center py-12 border bg-slate-50 border-dashed border-slate-200 rounded">
                <ClipboardList className="w-10 h-10 text-slate-300 mx-auto mb-3" />
                <h4 className="text-sm font-bold text-slate-600">Bạn chưa đặt mua đơn hàng nào!</h4>
                <p className="text-xs text-slate-400 mt-1">Sử dụng giỏ hàng để khởi tạo hóa đơn đấu thầu ngay.</p>
                <button
                  type="button"
                  onClick={() => onNavigateToTab('danh-mục')}
                  className="mt-4 bg-primary text-white font-bold text-xs uppercase px-4 py-2 rounded"
                >
                  Duyệt hàng
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                {[...orders].reverse().map((order) => (
                  <div key={order.id} className="bg-white border border-slate-200 rounded-lg p-5 space-y-4 shadow-sm">
                    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 border-b border-slate-100 pb-3">
                      <div>
                        <span className="text-xs text-slate-400 font-bold">Mã số hóa đơn:</span>
                        <h4 className="font-mono text-sm font-black text-slate-800 uppercase text-primary tracking-wide">
                          {order.id}
                        </h4>
                      </div>
                      <div className="flex flex-col sm:items-end gap-1">
                        <span className="text-xs text-slate-400 font-medium">Đặt ngày: {order.date}</span>
                        {getOrderStatusLabel(order.status)}
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                      <div className="space-y-1.5">
                        <p className="text-slate-400 font-bold uppercase tracking-wider text-[10px]">Recipient</p>
                        <p className="font-bold text-slate-800">{order.customerName}</p>
                        <p className="text-slate-500 font-medium">{order.phone}</p>
                        <p className="text-slate-500 font-medium flex items-center gap-1">
                          <MapPin className="w-3.5 h-3.5 hover:text-slate-700 text-slate-400 flex-shrink-0" />
                          <span className="truncate max-w-[200px]" title={order.address}>{order.address}</span>
                        </p>
                      </div>

                      <div className="space-y-1.5">
                        <p className="text-slate-400 font-bold uppercase tracking-wider text-[10px]">Tóm lược mặt hàng</p>
                        <div className="max-h-24 overflow-y-auto space-y-1 pr-1">
                          {order.items.map((it, idx) => (
                            <div key={idx} className="flex justify-between text-slate-600 font-medium">
                              <span className="truncate max-w-[170px]">{it.product.name}</span>
                              <span className="font-mono bg-slate-100 px-1 py-0.2 rounded text-[10px] text-slate-500">
                                x{it.quantity}
                              </span>
                            </div>
                          ))}
                        </div>
                        <div className="flex justify-between pt-1 border-t border-slate-100 font-bold font-mono text-sm">
                          <span className="text-slate-700">Giá trị đơn hàng:</span>
                          <span className="text-primary font-bold">{formatVND(order.total)}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
