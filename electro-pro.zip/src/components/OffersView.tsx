import React, { useState } from 'react';
import { Tag, Copy, Check, Gift, ArrowRight, Clock, Star, Percent } from 'lucide-react';
import { COUPONS } from '../data';

interface OffersViewProps {
  onNavigateToTab: (tab: string) => void;
}

export default function OffersView({ onNavigateToTab }: OffersViewProps) {
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  const handleCopyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  return (
    <div id="offers-view" className="space-y-8 py-2 select-text">
      {/* Title */}
      <div className="border-b border-slate-200 pb-3">
        <h2 className="text-2xl font-bold tracking-tight text-slate-900 uppercase">Ưu đãi & Khuyến mãi</h2>
        <p className="text-xs text-slate-500 mt-1">
          Chương trình ưu đãi dành riêng cho đại lý, thợ điện lành nghề và nhà thầu xây dựng
        </p>
      </div>

      {/* Featured Banner */}
      <div className="bg-gradient-to-r from-blue-700 to-indigo-800 text-white p-6 md:p-8 rounded-lg flex flex-col md:flex-row justify-between items-start md:items-center gap-6 shadow-sm">
        <div className="space-y-2 max-w-xl">
          <span className="bg-white/20 text-white font-bold text-[10px] uppercase tracking-wider px-2.5 py-1 rounded inline-block">
            SIÊU ƯU ĐÃI THẦU CÔNG TRÌNH
          </span>
          <h3 className="text-xl md:text-2xl font-bold tracking-tight">Chiết khấu toàn đoàn lên đến 30%</h3>
          <p className="text-xs md:text-sm text-slate-100 font-medium">
            Có đầy đủ báo giá đại lý tốt nhất toàn quốc cho đơn đặt mua tủ điện công nghiệp gia đình, dự án thương mại, nhà xưởng dệt may hoặc văn phòng làm việc. Liên hệ ngay hỗ trợ viên để lấy biểu phí chi tiết!
          </p>
        </div>
        <button 
          onClick={() => onNavigateToTab('giỏ-hàng')}
          className="bg-white text-blue-800 font-bold px-6 py-3 rounded text-xs uppercase tracking-wider hover:bg-slate-50 transition-colors shrink-0 flex items-center gap-1.5 shadow"
        >
          Áp dụng ngay <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* Coupons grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {COUPONS.map((coupon) => (
          <div key={coupon.code} className="bg-white border-2 border-dashed border-slate-200 rounded-lg p-5 flex flex-col justify-between hover:border-primary transition-colors relative overflow-hidden">
            <div className="absolute -top-3 -right-3 w-8 h-8 rounded-full bg-slate-50 border border-slate-200"></div>
            <div className="absolute -bottom-3 -right-3 w-8 h-8 rounded-full bg-slate-50 border border-slate-200"></div>

            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <div className="bg-blue-50 p-2 text-primary rounded">
                  {coupon.discountType === 'percent' ? (
                    <Percent className="w-5 h-5 text-primary" />
                  ) : (
                    <Gift className="w-5 h-5 text-primary" />
                  )}
                </div>
                <div>
                  <span className="text-slate-400 text-[10px] font-bold block uppercase tracking-wider">Mã Giảm Giá</span>
                  <span className="font-mono font-extrabold text-sm text-slate-800 bg-slate-100 px-2 py-0.5 rounded">
                    {coupon.code}
                  </span>
                </div>
              </div>

              <div>
                <p className="text-sm font-bold text-slate-800">{coupon.description}</p>
                <div className="space-y-1.5 mt-3 text-xs text-slate-500 font-medium">
                  <div className="flex items-center gap-1 text-slate-400">
                    <Clock className="w-3.5 h-3.5" />
                    <span>Hạn sử dụng: 31/12/2026</span>
                  </div>
                  {coupon.minOrderValue && (
                    <div className="flex items-center gap-1">
                      <Star className="w-3.5 h-3.5 text-amber-500" />
                      <span>Áp dụng đơn từ: <strong className="text-slate-700">{coupon.minOrderValue.toLocaleString('vi-VN')}đ</strong></span>
                    </div>
                  )}
                  {coupon.applicableCategory && (
                    <span className="inline-block bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded text-[10px] font-bold mt-1">
                      Chỉ áp dụng: Thiết bị đóng cắt (Breakers)
                    </span>
                  )}
                </div>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-100 flex items-center gap-2">
              <button
                onClick={() => handleCopyCode(coupon.code)}
                className={`flex-1 flex items-center justify-center gap-1 px-4 py-2 text-xs font-bold uppercase rounded border transition-colors ${
                  copiedCode === coupon.code
                    ? 'border-emerald-600 bg-emerald-50 text-emerald-700'
                    : 'border-slate-300 hover:border-slate-400 text-slate-700 hover:bg-slate-50'
                }`}
              >
                {copiedCode === coupon.code ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-600" />
                    Đã sao chép
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4 text-slate-400" />
                    Sao chép mã
                  </>
                )}
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Helpful FAQ Tips */}
      <div className="bg-slate-50 border border-slate-200 p-6 rounded-lg space-y-4">
        <h4 className="font-bold text-slate-800 uppercase flex items-center gap-2">
          <Tag className="w-5 h-5 text-primary" /> Hướng dẫn dùng mã ưu đãi
        </h4>
        <ul className="list-decimal list-inside text-xs text-slate-600 space-y-2.5 font-medium leading-relaxed">
          <li><strong>BƯỚC 1:</strong> Nhấn chọn "Sao chép" một trong các mã giảm giá hiển thị ở trên của ELECTRO PRO.</li>
          <li><strong>BƯỚC 2:</strong> Vào mục <strong>Giỏ hàng</strong>, kiểm tra danh mục sản phầm, giá trị giỏ hàng đã đạt hạn tối thiểu chưa (ví dụ đơn từ 200.000đ).</li>
          <li><strong>BƯỚC 3:</strong> Dán mã vừa sao chép vào ô "Mã giảm giá" và bấm <strong>Áp dụng</strong>. Hệ thống sẽ tự động trừ triết khấu.</li>
          <li><strong>LƯU Ý:</strong> Cứ thiết kế đơn hàng bao gồm tủ điện hoặc hạt công tắc Panasonic thì khuyến cáo dùng mã \`THANG10\` để nhận ưu đãi cao nhất nhé!</li>
        </ul>
      </div>
    </div>
  );
}
