import React, { useState, useEffect } from 'react';
import { Search, SlidersHorizontal, ArrowUpDown, ShieldAlert, CheckCircle, Tag, Sparkles, Filter, X } from 'lucide-react';
import { Product } from '../types';
import { CATEGORIES, PRODUCTS } from '../data';
import ProductCard from './ProductCard';

interface CategoriesViewProps {
  initialCategory?: string;
  initialManufacturer?: string;
  onAddToCart: (product: Product, quantity: number) => void;
  onViewDetails: (product: Product) => void;
}

export default function CategoriesView({
  initialCategory,
  initialManufacturer,
  onAddToCart,
  onViewDetails,
}: CategoriesViewProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>(initialCategory || 'all');
  const [selectedBrand, setSelectedBrand] = useState<string>(initialManufacturer || 'all');
  const [minPrice, setMinPrice] = useState<number>(0);
  const [maxPrice, setMaxPrice] = useState<number>(1000000);
  const [sortBy, setSortBy] = useState<string>('featured');
  const [filteredProducts, setFilteredProducts] = useState<Product[]>(PRODUCTS);
  const [showMobileFilters, setShowMobileFilters] = useState(false);

  // Sync with main app redirects
  useEffect(() => {
    if (initialCategory) {
      setSelectedCategory(initialCategory);
    }
  }, [initialCategory]);

  useEffect(() => {
    if (initialManufacturer) {
      setSelectedBrand(initialManufacturer);
    }
  }, [initialManufacturer]);

  // Apply filters whenever input state updates
  useEffect(() => {
    let result = PRODUCTS;

    // Search filter
    if (searchTerm.trim() !== '') {
      const q = searchTerm.toLowerCase();
      result = result.filter(
        p =>
          p.name.toLowerCase().includes(q) ||
          p.manufacturer.toLowerCase().includes(q) ||
          p.refCode.toLowerCase().includes(q) ||
          p.specs['Màu sắc']?.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q)
      );
    }

    // Category filter
    if (selectedCategory !== 'all') {
      result = result.filter(p => p.category === selectedCategory);
    }

    // Brand filter
    if (selectedBrand !== 'all') {
      result = result.filter(
        p => p.manufacturer.toLowerCase().includes(selectedBrand.toLowerCase())
      );
    }

    // Price range filters
    result = result.filter(p => p.price >= minPrice && p.price <= maxPrice);

    // Sorting
    if (sortBy === 'price-asc') {
      result = [...result].sort((a, b) => a.price - b.price);
    } else if (sortBy === 'price-desc') {
      result = [...result].sort((a, b) => b.price - a.price);
    } else if (sortBy === 'name-asc') {
      result = [...result].sort((a, b) => a.name.localeCompare(b.name));
    }

    setFilteredProducts(result);
  }, [searchTerm, selectedCategory, selectedBrand, minPrice, maxPrice, sortBy]);

  const uniqueManufacturers = Array.from(new Set(PRODUCTS.map(p => p.manufacturer)));

  const handleResetFilters = () => {
    setSearchTerm('');
    setSelectedCategory('all');
    setSelectedBrand('all');
    setMinPrice(0);
    setMaxPrice(1000000);
    setSortBy('featured');
  };

  const formatVND = (num: number) => {
    return num.toLocaleString('vi-VN') + 'đ';
  };

  return (
    <div id="catalog-view" className="space-y-6 py-2 select-text">
      {/* Title */}
      <div className="border-b border-slate-200 pb-3 flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-slate-900 uppercase">Danh mục sản phẩm</h2>
          <p className="text-xs text-slate-500 mt-1">Lọc tìm thiết bị điện chính hãng từ tổng kho phân phối</p>
        </div>
        <button
          onClick={() => setShowMobileFilters(!showMobileFilters)}
          className="lg:hidden flex items-center gap-1.5 bg-primary text-white px-3 py-2 rounded text-xs font-semibold uppercase active:scale-95 transition-transform"
        >
          <Filter className="w-3.5 h-3.5" />
          Lọc hàng
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Sidebar Filters (Desktop) */}
        <aside className={`lg:block ${showMobileFilters ? 'fixed inset-0 bg-white z-[60] overflow-y-auto p-6 flex flex-col justify-between' : 'hidden'} space-y-6 lg:bg-transparent lg:p-0`}>
          {showMobileFilters && (
            <div className="flex justify-between items-center border-b border-slate-200 pb-4 mb-2 lg:hidden">
              <span className="font-bold text-slate-800 uppercase flex items-center gap-1">
                <SlidersHorizontal className="w-4 h-4" /> Bộ lọc sản phẩm
              </span>
              <button 
                onClick={() => setShowMobileFilters(false)}
                className="p-1 hover:bg-slate-100 rounded-full"
                aria-label="Đóng bộ lọc"
              >
                <X className="w-6 h-6 text-slate-500" />
              </button>
            </div>
          )}

          <div className="space-y-6">
            {/* Search Input inside block */}
            <div className="space-y-2">
              <label htmlFor="search-input" className="text-xs font-bold text-slate-700 uppercase tracking-wider block">Tìm nhanh</label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
                <input
                  id="search-input"
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Mã SP, từ khóa..."
                  className="w-full bg-slate-50 border border-slate-300 rounded px-2.5 py-2 pl-9 text-sm text-slate-800 focus:ring-1 focus:ring-primary focus:border-primary focus:outline-none"
                />
              </div>
            </div>

            {/* Category Filter */}
            <div className="space-y-2">
              <label htmlFor="category-select" className="text-xs font-bold text-slate-700 uppercase tracking-wider block">Phân loại</label>
              <select
                id="category-select"
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded p-2.5 text-sm text-slate-800 focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary"
              >
                <option value="all">Tất cả danh mục hàng</option>
                {CATEGORIES.map(cat => (
                  <option key={cat.id} value={cat.id}>{cat.label}</option>
                ))}
              </select>
            </div>

            {/* Brand Filter */}
            <div className="space-y-2">
              <label htmlFor="brand-select" className="text-xs font-bold text-slate-700 uppercase tracking-wider block">Thương hiệu</label>
              <select
                id="brand-select"
                value={selectedBrand}
                onChange={(e) => setSelectedBrand(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded p-2.5 text-sm text-slate-800 focus:outline-none focus:ring-1 focus:ring-primary"
              >
                <option value="all">Tất cả hãng sản xuất</option>
                {uniqueManufacturers.map((brand, i) => (
                  <option key={i} value={brand}>{brand}</option>
                ))}
              </select>
            </div>

            {/* Price Filter Slider and text */}
            <div className="space-y-3">
              <div className="flex justify-between items-center text-xs font-bold text-slate-700 uppercase tracking-wider">
                <span>Khoảng giá</span>
                <span className="text-primary font-mono lowercase">{formatVND(maxPrice)}</span>
              </div>
              <input
                type="range"
                min="0"
                max="1000000"
                step="5000"
                value={maxPrice}
                onChange={(e) => setMaxPrice(Number(e.target.value))}
                className="w-full accent-primary bg-slate-200 h-1.5 rounded-lg appearance-none cursor-pointer"
              />
              <div className="flex justify-between text-[11px] text-slate-400 font-bold">
                <span>0đ</span>
                <span>1.000.000đ</span>
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-200 flex flex-col gap-2">
            <button
              onClick={handleResetFilters}
              className="w-full border border-slate-300 text-slate-600 font-bold hover:bg-slate-100 py-2.5 text-xs uppercase tracking-wider rounded transition-colors"
            >
              Thiết lập lại bộ lọc
            </button>
            {showMobileFilters && (
              <button
                onClick={() => setShowMobileFilters(false)}
                className="w-full bg-primary text-white font-bold py-2.5 text-xs uppercase tracking-wider rounded transition-colors lg:hidden"
              >
                Áp dụng bộ lọc
              </button>
            )}
          </div>
        </aside>

        {/* Content Area */}
        <div className="lg:col-span-3 space-y-6">
          {/* Active stats bar */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center bg-slate-50 border border-slate-200 p-3 rounded text-sm gap-2">
            <div className="text-slate-600 font-medium">
              Đang hiển thị <span className="text-primary font-bold">{filteredProducts.length}</span> sản phẩm phù hợp
            </div>
            
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <label htmlFor="sort-select" className="text-slate-400 text-xs font-bold whitespace-nowrap uppercase">Sắp xếp:</label>
              <select
                id="sort-select"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="bg-white border border-slate-300 text-xs rounded p-1.5 focus:outline-none text-slate-700"
              >
                <option value="featured">Nổi tiếng / Mặc định</option>
                <option value="price-asc">Giá từ thấp đến cao</option>
                <option value="price-desc">Giá từ cao đến thấp</option>
                <option value="name-asc">Tên sản phẩm A-Z</option>
              </select>
            </div>
          </div>

          {/* Product Grid representation */}
          {filteredProducts.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredProducts.map((p) => (
                <ProductCard
                  key={p.id}
                  product={p}
                  onAddToCart={onAddToCart}
                  onViewDetails={onViewDetails}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-16 border rounded bg-slate-50 border-dashed border-slate-300">
              <ShieldAlert className="w-12 h-12 text-slate-400 mx-auto mb-4" />
              <h3 className="text-lg font-bold text-slate-700">Không tìm thấy sản phẩm nào!</h3>
              <p className="text-sm text-slate-500 mt-1 max-w-md mx-auto">
                Không tìm thấy mặt hàng phù hợp với bộ lọc kỹ thuật của bạn. Thử gõ tìm một thiết bị khác hoặc khôi phục cài đặt.
              </p>
              <button
                type="button"
                onClick={handleResetFilters}
                className="mt-6 bg-primary text-white font-bold text-xs uppercase px-5 py-2.5 rounded hover:bg-blue-800"
              >
                Xem lại toàn bộ danh mục
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
