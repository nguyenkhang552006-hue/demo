import React, { useState } from 'react';
import { X, ShoppingCart, Check, ShieldCheck, Cpu, Zap, Star } from 'lucide-react';
import { Product } from '../types';

interface ProductDetailModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (product: Product, quantity: number) => void;
  relatedProducts: Product[];
  onSelectProduct: (product: Product) => void;
}

export default function ProductDetailModal({
  product,
  onClose,
  onAddToCart,
  relatedProducts,
  onSelectProduct,
}: ProductDetailModalProps) {
  const [qty, setQty] = useState(1);
  const [isAdded, setIsAdded] = useState(false);

  if (!product) return null;

  const handleAdd = () => {
    onAddToCart(product, qty);
    setIsAdded(true);
    setTimeout(() => {
      setIsAdded(false);
      onClose();
    }, 1200);
  };

  const formatVND = (num: number) => {
    return num.toLocaleString('vi-VN') + 'đ';
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 flex items-center justify-center p-4 z-[100] overflow-y-auto animate-in fade-in duration-200 select-text">
      {/* Target ID attribute added according to HTML ID Attribute Guidelines */}
      <div id="product-detail-modal-container" className="bg-white rounded-xl border border-slate-200 w-full max-w-4xl max-h-[90vh] overflow-y-auto shadow-2xl relative flex flex-col md:flex-row p-6 md:p-8 gap-8 animate-in zoom-in-95 duration-200">
        
        {/* Close Button top-right */}
        <button 
          onClick={onClose} 
          className="absolute top-4 right-4 text-slate-400 hover:text-slate-700 hover:bg-slate-50 p-2 rounded-full transition-colors"
          aria-label="Đóng chi tiết"
        >
          <X className="w-6 h-6" />
        </button>

        {/* Left Side: Product Illustration with brand watermark */}
        <div className="flex-1 space-y-4">
          <div className="bg-slate-50 border border-slate-200 rounded-lg p-6 h-72 md:h-96 flex items-center justify-center relative select-none">
            <img 
              alt={product.name} 
              src={product.image} 
              referrerPolicy="no-referrer"
              className="max-h-full max-w-full object-contain mix-blend-multiply" 
            />
            <span className="absolute bottom-2 left-3 font-mono text-[9px] text-slate-400 font-bold tracking-widest uppercase">
              Electro Pro Technical Standard
            </span>
          </div>

          {/* Related items section inside details */}
          {relatedProducts.length > 0 && (
            <div className="space-y-3 pt-2">
              <span className="text-xs font-bold text-slate-600 uppercase tracking-wider block">Thiết bị tương quan:</span>
              <div className="grid grid-cols-2 gap-3">
                {relatedProducts.slice(0, 2).map((rel) => (
                  <div 
                    key={rel.id}
                    onClick={() => {
                      onSelectProduct(rel);
                      setQty(1);
                    }}
                    className="border border-slate-150 p-2 bg-slate-50 rounded flex items-center gap-2 cursor-pointer hover:border-primary transition-colors"
                  >
                    <div className="w-8 h-8 bg-white border p-1 rounded flex-shrink-0 flex items-center justify-center">
                      <img alt={rel.name} src={rel.image} className="max-h-full object-contain" />
                    </div>
                    <div className="overflow-hidden">
                      <span className="text-[10px] text-slate-400 font-bold block truncate">{rel.manufacturer}</span>
                      <span className="text-[11px] text-slate-800 font-semibold block truncate">{rel.name}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Right Side: Technical Specs & Add Controls */}
        <div className="flex-1 flex flex-col justify-between space-y-6">
          <div className="space-y-4">
            <div>
              <span className="bg-primary/10 text-primary text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-widest">
                {product.categoryVietnamese}
              </span>
              <h3 className="text-xl md:text-2xl font-bold font-space-grotesk text-slate-900 mt-2 leading-tight">
                {product.name}
              </h3>
              <p className="text-xs text-slate-400 font-mono mt-1 font-bold uppercase">
                Mã kỹ thuật: {product.refCode} | Hãng: {product.manufacturer}
              </p>
            </div>

            <div className="border-t border-b border-slate-150 py-3 flex items-baseline gap-4">
              <span className="text-2xl md:text-3xl font-black text-primary">{formatVND(product.price)}</span>
              {product.originalPrice && (
                <span className="text-slate-400 line-through text-xs md:text-sm font-semibold">
                  {formatVND(product.originalPrice)}
                </span>
              )}
            </div>

            <div className="space-y-2">
              <h4 className="text-xs font-bold text-slate-600 uppercase tracking-widest block">Mô tả sản phẩm</h4>
              <p className="text-xs text-slate-500 leading-relaxed font-medium">
                {product.description}
              </p>
            </div>

            {/* Specifications Technical Data Table with zebra rows */}
            <div className="space-y-2.5">
              <h4 className="text-xs font-bold text-slate-600 uppercase tracking-widest block">Thông số kỹ thuật chi tiết</h4>
              <div className="border border-slate-200 rounded overflow-hidden text-xs">
                <table className="w-full border-collapse">
                  <tbody>
                    {Object.entries(product.specs).map(([key, value], i) => (
                      <tr key={i} className={i % 2 === 0 ? 'bg-slate-50' : 'bg-white'}>
                        <td className="p-2.5 font-bold text-slate-600 border-r border-slate-100 w-[140px] uppercase tracking-wider text-[10px]">{key}</td>
                        <td className="p-2.5 font-mono text-slate-800 font-medium">{value}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Quick controls panel */}
          <div className="bg-slate-50 border border-slate-200 p-4 rounded-xl flex items-center justify-between gap-4 mt-auto">
            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Chọn số lượng:</span>
              <div className="flex items-center border border-slate-300 rounded overflow-hidden select-none bg-white">
                <button
                  type="button"
                  onClick={() => setQty(Math.max(1, qty - 1))}
                  className="px-3 py-1.5 hover:bg-slate-100 text-slate-500 font-bold"
                >
                  -
                </button>
                <span className="px-4 py-1 font-mono text-xs font-bold text-slate-800 bg-slate-50 select-text">
                  {qty}
                </span>
                <button
                  type="button"
                  onClick={() => setQty(qty + 1)}
                  className="px-3 py-1.5 hover:bg-slate-100 text-slate-500 font-bold"
                >
                  +
                </button>
              </div>
            </div>

            <button
              onClick={handleAdd}
              className={`flex-1 flex items-center justify-center gap-1.5 py-3 px-5 text-xs font-bold uppercase tracking-wider rounded-lg transition-transform ${
                isAdded 
                  ? 'bg-emerald-600 text-white cursor-default' 
                  : 'bg-primary text-white hover:bg-blue-800 active:scale-95 shadow-md shadow-primary/10'
              }`}
            >
              {isAdded ? (
                <>
                  <Check className="w-4 h-4" /> Đã thêm vào giỏ hàng
                </>
              ) : (
                <>
                  <ShoppingCart className="w-4 h-4" /> Cho vào giỏ mua
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
