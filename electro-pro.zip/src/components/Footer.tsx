import React from 'react';
import { Bolt, Phone, Mail, Award, RotateCcw, ShieldAlert, Heart } from 'lucide-react';

interface FooterProps {
  onNavigateToTab: (tab: string) => void;
}

export default function Footer({ onNavigateToTab }: FooterProps) {
  return (
    <footer className="bg-slate-950 text-white py-12 border-t-4 border-primary select-text">
      <div className="max-w-[1280px] mx-auto px-6 md:px-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
        
        {/* Brand overview */}
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <div className="bg-primary p-1.5 rounded text-white flex-shrink-0">
              <Bolt className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-extrabold uppercase tracking-tighter">ELECTRO PRO</span>
          </div>
          <p className="text-slate-400 text-xs leading-relaxed font-medium">
            Nhà phân phối thiết bị điện hạ thế, thiết bị đóng cắt an toàn, chiếu sáng và dây cáp lực hàng đầu Việt Nam. Đối tác tin cậy của mọi Ban quản lý dự án & nhà thầu M&E cơ điện.
          </p>
        </div>

        {/* Customer Care widgets */}
        <div className="space-y-4">
          <h4 className="text-xs font-bold text-white uppercase tracking-wider">Hỗ trợ đối tác</h4>
          <ul className="space-y-2.5 text-xs text-slate-400 font-medium">
            <li>
              <button onClick={() => onNavigateToTab('ưu-đãi')} className="hover:text-primary transition-colors text-left">
                Chính sách chiết khấu đại lý
              </button>
            </li>
            <li>
              <a href="#" className="hover:text-primary transition-colors">
                Hướng dẫn kiểm tra thông mạch & CO/CQ
              </a>
            </li>
            <li>
              <a href="#" className="hover:text-primary transition-colors">
                Quy trình vận chuyển chân công trình
              </a>
            </li>
          </ul>
        </div>

        {/* Fast shortcuts */}
        <div className="space-y-4">
          <h4 className="text-xs font-bold text-white uppercase tracking-wider">Đường dẫn nhanh</h4>
          <ul className="space-y-2.5 text-xs text-slate-400 font-medium">
            <li>
              <button onClick={() => onNavigateToTab('trang-chủ')} className="hover:text-primary transition-colors">
                Trang chủ cửa hàng
              </button>
            </li>
            <li>
              <button onClick={() => onNavigateToTab('danh-mục')} className="hover:text-primary transition-colors">
                Danh mục vật tư hạ thế
              </button>
            </li>
            <li>
              <button onClick={() => onNavigateToTab('tài-khoản')} className="hover:text-primary transition-colors">
                Hóa đơn thi công cá nhân
              </button>
            </li>
          </ul>
        </div>

        {/* Reach out details */}
        <div className="space-y-4">
          <h4 className="text-xs font-bold text-white uppercase tracking-wider">Liên hệ kho hàng</h4>
          <div className="space-y-3.5 text-xs text-slate-400 font-medium font-mono">
            <div className="flex items-center gap-2.5">
              <Phone className="w-4 h-4 text-primary" />
              <span>1900 1234 (8:00 - 18:00)</span>
            </div>
            <div className="flex items-center gap-2.5">
              <Mail className="w-4 h-4 text-primary" />
              <span className="font-sans">contact@electropro.com</span>
            </div>
            <p className="font-sans text-[11px] text-slate-500 leading-normal">
              Kho bãi: Quốc lộ 1A, Bình Tân, Thành phố Hồ Chí Minh.
            </p>
          </div>
        </div>

      </div>

      {/* Trust guarantees bar */}
      <div className="max-w-[1280px] mx-auto px-6 md:px-8 mt-12 pt-8 border-t border-slate-900 text-slate-500 text-[11px] flex flex-col sm:flex-row justify-between gap-4 font-medium select-none">
        <p>© 2026 ELECTRO PRO JSC. Bảo lưu mọi quyền thương hiệu.</p>
        <div className="flex flex-wrap gap-4 items-center">
          <span className="flex items-center gap-1"><Award className="w-4 h-4 text-primary" /> Đạt chuẩn TCVN</span>
          <span className="flex items-center gap-1"><RotateCcw className="w-4 h-4 text-primary" /> Đổi trả 7 ngày</span>
          <span className="flex items-center gap-1"><ShieldCheck className="w-4 h-4 text-primary" /> BH 12 tháng</span>
        </div>
      </div>
    </footer>
  );
}

const ShieldCheck = ({ className }: { className?: string }) => (
  <svg 
    className={className} 
    fill="none" 
    stroke="currentColor" 
    viewBox="0 0 24 24" 
    strokeWidth="2"
  >
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
  </svg>
);
